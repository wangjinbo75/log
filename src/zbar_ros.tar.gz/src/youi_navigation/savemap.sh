#!/bin/bash
source /opt/ros/kinetic/setup.bash
source ~/catkin_ws/devel/setup.bash
source ~/cartographer/install_isolated/setup.bash

rosservice call /write_state /home/youibot/catkin_ws/src/youi_navigation/map/firstMap.pbstream
rosrun cartographer_ros cartographer_pbstream_to_ros_map -map_filestem=/home/youibot/catkin_ws/src/youi_navigation/map/firstMap -pbstream_filename=/home/youibot/catkin_ws/src/youi_navigation/map/firstMap.pbstream -resolution=0.03



