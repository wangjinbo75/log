打开摄像头报错:
HIGHGUI ERROR: V4L/V4L2: VIDIOC_S_CROP
解决办法:
sudo apt-get install libv4l-dev
