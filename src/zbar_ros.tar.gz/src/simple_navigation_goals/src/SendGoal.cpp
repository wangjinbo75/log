#include "simple_navigation_goals/SendGoal.h"
#include "yaml-cpp/yaml.h"
#include <chrono>
#include <fstream>
#include <sstream>
#include "tf2_geometry_msgs/tf2_geometry_msgs.h"

namespace YAML
{
template <>
struct convert<Vec7>
{
    static Node encode(const Vec7 &rhs)
    {
        Node node;
        node.push_back(rhs.x);
        node.push_back(rhs.y);
        node.push_back(rhs.z);
        node.push_back(rhs.a);
        node.push_back(rhs.b);
        node.push_back(rhs.c);
        node.push_back(rhs.d);
        return node;
    }

    static bool decode(const Node &node, Vec7 &rhs)
    {
        int len = 7;
        if (!node.IsSequence() || node.size() != len)
        {
            return false;
        }

        rhs.x = node[0].as<double>();
        rhs.y = node[1].as<double>();
        rhs.z = node[2].as<double>();
        rhs.a = node[3].as<double>();
        rhs.b = node[4].as<double>();
        rhs.c = node[5].as<double>();
        rhs.d = node[6].as<double>();
        return true;
    }
};
Emitter &operator<<(YAML::Emitter &out, const Vec7 &v)
{
    out << Flow;
    out << BeginSeq << v.x << v.y << v.z << v.a << v.b << v.c << v.d << EndSeq;
    return out;
}

} // namespace YAML

const static int kSleep = 20;
const static std::string kFile1 = "/home/youibot/catkin_ws/src/simple_navigation_goals/param/param1.yaml";

SendGoal::SendGoal(ros::NodeHandle nh)
    : _nh(nh), _isRunning(false), _isGoal(false), _isAmclPose(false)
{
    _initPosePub = _nh.advertise<geometry_msgs::PoseWithCovarianceStamped>("/initialpose", 10);
    _goalSub = _nh.subscribe("/send_goals", 10, &SendGoal::GoalCallBack, this);
    _amclPoseSub = _nh.subscribe("/amcl_pose", 10, &SendGoal::AmclPoseCallBack, this);
    StartThread();
}

SendGoal::~SendGoal()
{
    StopThread();
}

void SendGoal::GoalCallBack(const std_msgs::String &msg)
{

    _reciveGoal = msg.data.c_str();
    ROS_INFO("_reciveGoal = %s\n", _reciveGoal);
    _isGoal = true;
}

void SendGoal::AmclPoseCallBack(const geometry_msgs::PoseWithCovarianceStamped &msg)
{

    _currPose.pose.pose.position.x = msg.pose.pose.position.x;
    _currPose.pose.pose.position.y = msg.pose.pose.position.y;
    _currPose.pose.pose.position.z = msg.pose.pose.position.z;
    _currPose.pose.pose.orientation.x = msg.pose.pose.orientation.x;
    _currPose.pose.pose.orientation.y = msg.pose.pose.orientation.y;
    _currPose.pose.pose.orientation.z = msg.pose.pose.orientation.z;
    _currPose.pose.pose.orientation.w = msg.pose.pose.orientation.w;
    _isAmclPose = true;
}

void SendGoal::StartThread()
{
    ROS_INFO("start thread");
   
    if (_thread1.joinable())
    {
        _thread1.join();
    }
    _isRunning = true;
    _thread1 = std::thread(std::bind(&SendGoal::SetInitPoseThread, this));
}

void SendGoal::StopThread()
{
    _isRunning = false;
    
    if (_thread1.joinable())
    {
        ROS_WARN("thread is shut down");
        _thread1.join();
    }
}


void SendGoal::SetInitPoseThread()
{
    
    YAML::Node node = YAML::LoadFile(kFile1);
    Vec7 v = node["init_pose"].as<Vec7>();
    ROS_INFO("Allready Send Home!!!x = %f, y = %f, z = %f, a = %f, b = %f, c = %f, d = %f\n", v.x, v.y, v.z, v.a, v.b, v.c, v.d);
    SetHome(v);
    while (_isRunning && ros::ok())
    {
        if (_isAmclPose)
        {
            _isAmclPose = false;
            std::ofstream fout(kFile1);
            YAML::Emitter out(fout);
            out << YAML::BeginMap;
            out << YAML::Key << "init_pose";
            out << YAML::Flow;
            out << YAML::BeginSeq << _currPose.pose.pose.position.x
                << _currPose.pose.pose.position.y
                << _currPose.pose.pose.position.z
                << _currPose.pose.pose.orientation.x
                << _currPose.pose.pose.orientation.y
                << _currPose.pose.pose.orientation.z
                << _currPose.pose.pose.orientation.w << YAML::EndSeq;
            out << YAML::EndMap;
            //ROS_INFO("+++++++++++++++++++");
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(kSleep));
    }
}

void SendGoal::SetHome(const Vec7 &pose)
{
    MoveBaseClient ac("move_base", true);
    while (!ac.waitForServer(ros::Duration(5.0)))
    {
        ROS_WARN("Waiting for the move_base action server to come up");
    }
    geometry_msgs::PoseWithCovarianceStamped initPose;
    initPose.header.frame_id = "/map";
    initPose.header.stamp = ros::Time::now();
    initPose.pose.pose.position.x = pose.x;
    initPose.pose.pose.position.y = pose.y;
    initPose.pose.pose.position.z = pose.z;
    initPose.pose.pose.orientation.x = pose.a;
    initPose.pose.pose.orientation.y = pose.b;
    initPose.pose.pose.orientation.z = pose.c;
    initPose.pose.pose.orientation.w = pose.d;

    _initPosePub.publish(initPose);
    ros::Duration(1.0).sleep();
    _initPosePub.publish(initPose);
    ros::Duration(1.0).sleep();
    _initPosePub.publish(initPose);
    ros::Duration(1.0).sleep();
    _initPosePub.publish(initPose);
    ros::Duration(1.0).sleep();
    _initPosePub.publish(initPose);
    ros::Duration(1.0).sleep();
}


