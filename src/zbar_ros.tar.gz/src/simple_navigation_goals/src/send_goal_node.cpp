/*
 * @Author: wangning 
 * @Date: 2018-08-17 17:17:34 
 * @Last Modified by:   wangning 
 * @Last Modified time: 2018-08-17 17:17:34 
 */

#include "ros/ros.h"
#include "simple_navigation_goals/SendGoal.h"
int main(int argc, char **argv)
{
    // Set up ROS.
    ros::init(argc, argv, "send_goals");
    ros::NodeHandle nh;

    // Create a new node_example::Talker object.
    SendGoal node(nh);

    // Let ROS handle all callbacks.
    ros::spin();

    return 0;
} // end main()