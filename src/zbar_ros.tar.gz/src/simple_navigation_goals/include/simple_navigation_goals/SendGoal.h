/*
 * @Author: WangNing
 * @Date: 2018-08-20 11:58:42
 * @LastEditors: WangNing
 * @LastEditTime: 2018-08-20 11:58:42
 * @Description: 
 * @Email: wangning@youibot.com
 * @Company: Youibot Robotics Co., Ltd.
 * @youWant: add you want
 */

#ifndef __SENDGOAL_H__
#define __SENDGOAL_H__

#include <thread>

#include "ros/ros.h"
#include "move_base_msgs/MoveBaseAction.h"
#include "actionlib/client/simple_action_client.h"
#include "geometry_msgs/PoseWithCovarianceStamped.h"
#include "std_msgs/String.h"

struct Vec7
{
    double x, y, z, a, b, c, d;
};

class SendGoal
{
    typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;

public:
    SendGoal(ros::NodeHandle nh);
    ~SendGoal();

private:
    void StartThread();
    void StopThread();
    void SetInitPoseThread();

    void GoalCallBack(const std_msgs::String &msg);
    void AmclPoseCallBack(const geometry_msgs::PoseWithCovarianceStamped &msg);
    void SetHome(const Vec7 &pose);

private:
    ros::NodeHandle _nh;
    ros::Publisher _initPosePub;
    ros::Subscriber _amclPoseSub;
    ros::Subscriber _goalSub;

    std::thread _thread;
    std::thread _thread1;

    bool _isRunning;
    bool _isGoal;
    bool _isAmclPose;
    std::string _reciveGoal;
    geometry_msgs::PoseWithCovarianceStamped _currPose;
};
#endif // __SENDGOAL_H__