#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/lijianghua/trans_ws/src/ira_laser_tools/cmake-build-debug/devel:$CMAKE_PREFIX_PATH"
export ROSLISP_PACKAGE_DIRECTORIES="/home/lijianghua/trans_ws/src/ira_laser_tools/cmake-build-debug/devel/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH="/home/lijianghua/trans_ws/src/ira_laser_tools:/home/lijianghua/cartographer/install_isolated/share:/home/lijianghua/Desktop/JRC/realsense_workspace/src:/home/lijianghua/trans_ws/src:/opt/ros/kinetic/share"