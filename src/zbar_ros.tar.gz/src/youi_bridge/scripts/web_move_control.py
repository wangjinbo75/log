#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
 * @Author: WangNing
 * @Date: 2018-09-28 10:40:21
 * @LastEditors: WangNing
 * @LastEditTime: 2018-09-28 10:40:44
 * @Description:  接受网络客户端的指令控制底盘运动,前进,后退,右转,左转和急停  
 * @Email: wangning@youibot.com
 * @Company: Youibot Robotics Co., Ltd.
 * @youWant: add you want
'''

import logging
import logging.config
import random
import threading
import time
from logging.handlers import TimedRotatingFileHandler
import actionlib
import rospy
import std_msgs
from youi_bridge.msg import WebMove
from actionlib_msgs.msg import *
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Point,Pose, PoseArray, Quaternion, PoseStamped, Twist, TwistWithCovariance
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal

class Web_Move_Control():
    def __init__(self):
        rospy.init_node('web_move_control_node', anonymous=False)
        rospy.on_shutdown(self.shutdown)
        self.WebMove_sub = rospy.Subscriber("/WebMove", WebMove, self.w_m_callback)
        self.Move_base_status_sub  = rospy.Subscriber("/move_base/status",GoalStatusArray,self.m_b_Status_callback)
        self.speed_pub  = rospy.Publisher("/cmd_vel_mux/input/teleop",Twist, queue_size=10)

        self.linearVelocity = 0
        self.angularVelocity = 0
        # move_base goal status,1-move_base is running ,0-move_base is not running
        self.m_bStatus = 0
        # max speed for linear and angular
        self.max_linear_speed = 0.5
        self.max_angular_speed = 1
        
        self.is_run = True
        self.goStraight = 0
        self.goTurn = 0
        self.stop = 0

        self.current_speed_x = 0
        self.current_speed_z = 0 

        self.t1 = threading.Thread(target = self.speed_publish())
        self.t1.setDaemon(False)
        self.t1.start()


    def w_m_callback(self,msg):

        # goStraight, 1 - forward, -1 - goback
        if msg.goStraight == 1 or msg.goStraight == -1 or msg.goStraight == 0:
            self.goStraight = msg.goStraight
        else:
            pass
        # goStraight, 1 - turn right, -1 - turn left
        if msg.goTurn == 1 or msg.goTurn == -1 or msg.goTurn == 0:
            self.goTurn = msg.goTurn
        else:
            pass
        # stop , 1 - stop right now, 0 - move
        if msg.stop == 1 or msg.stop == 0:
            self.stop = msg.stop
            if self.stop == 1:
                self.goStraight = 0
                self.goTurn = 0
        else:
            pass
        # default max speed of linear and angular
        self.max_linear_speed = 0.5
        self.max_angular_speed = 1
        if msg.max_linear_x >= 0:
            self.max_linear_speed = min(0.5,msg.max_linear_x)
        else:
            pass
        if msg.max_angular_z >= 0:
            self.max_angular_speed = min(1,msg.max_angular_z)
        

    def m_b_Status_callback(self,msg):

        for sta in msg.status_list:

            if sta.status == 1:

                self.m_bStatus = 1

                break

            else:

                self.m_bStatus = 0

    def speed_cal(self):
 
        if self.goStraight == 0:

            if abs(self.linearVelocity) < 0.01:

                self.linearVelocity = 0

            else:

                self.linearVelocity = self.linearVelocity - (self.linearVelocity / abs(self.linearVelocity)) * 0.02
        
        else:

            if self.goStraight == 1:

                self.linearVelocity = min(self.linearVelocity + 0.02,self.max_linear_speed)

            if self.goStraight == -1:

                self.linearVelocity = max(self.linearVelocity - 0.02, - self.max_linear_speed)


        if self.goTurn == 0:

            if abs(self.angularVelocity) < 0.03:

                self.angularVelocity = 0

            else:
                
                self.angularVelocity = self.angularVelocity - (self.angularVelocity / abs(self.angularVelocity)) * 0.05

        else:
    
            if self.goTurn == -1:

                self.angularVelocity = min(self.angularVelocity + 0.05,self.max_angular_speed)
            
            if self.goTurn == 1:

                self.angularVelocity = max(self.angularVelocity - 0.05, - self.max_angular_speed)
                
        
    def speed_publish(self):

        twist = Twist()
        while(self.is_run):        
                    

                time.sleep(0.05)

                if self.m_bStatus == 1:

                    continue

                if self.stop == 1:
                    
                    twist.linear.x = 0
                    twist.angular.z = 0
                    self.linearVelocity = 0
                    self.angularVelocity = 0

                    for i in range(5):  
                        
                        self.speed_pub.publish(twist)

                    self.stop = 0

                    continue

                if self.goStraight == 0 and self.goTurn == 0 and self.angularVelocity == 0 and self.linearVelocity == 0:

                    continue

                else:

                    self.speed_cal()

                    twist.linear.x = self.linearVelocity
                    twist.angular.z = self.angularVelocity    

                    self.speed_pub.publish(twist)
            
        
    def shutdown(self):
        self.is_run = False
        rospy.logwarn("web control exception finished")

if __name__ == '__main__':
    
    try:
        Web_Move_Control()
        rospy.spin()
    except rospy.ROSInterruptException:
        rospy.logwarn("web control exception finished.")
