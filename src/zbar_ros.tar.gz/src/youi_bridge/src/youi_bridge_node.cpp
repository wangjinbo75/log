#include "broadcaster_server.h"
#include "ros/ros.h"
#include "std_msgs/Int32MultiArray.h"
#include "std_msgs/Int8.h"

#include "geometry_msgs/PoseWithCovarianceStamped.h"
#include "sensor_msgs/LaserScan.h"
#include "InlemsSensor.h"
#include "AutoNavigation.h"
#include "NavigationStatus.h"
#include "trans_drive/msgs/Battery.h"
#include "WebMove.h"
#include <cmath>
#include "tf/tf.h"
#include "tf/transform_broadcaster.h"

// websocket server
telemetry_server server;

void sensorCallback(const youi_bridge::InlemsSensor::ConstPtr& msg)
{
    server.robotInfo.server_dish_temp_1 = msg->server_STK[0];
    server.robotInfo.server_dish_temp_2 = msg->server_STK[1];
    server.robotInfo.server_dish_temp_3 = msg->server_STK[2];
    server.robotInfo.server_dish_temp_4 = msg->server_STK[3];
    server.robotInfo.server_dish_temp_5 = msg->server_STK[4];
    server.robotInfo.server_dish_temp_6 = msg->server_STK[5];
    server.robotInfo.server_dish_temp_7 = msg->server_STK[6];
    server.robotInfo.server_dish_temp_8 = msg->server_STK[7];

    server.robotInfo.server_n2 = msg->server_STL[0];
    server.robotInfo.server_seal_co2 = msg->server_seal_co2[0];
    server.robotInfo.server_non_seal_co2 = msg->server_non_seal_co2[0];
    server.robotInfo.server_wireless_o2 = msg->server_O2[0];
    server.robotInfo.server_temperature = msg->server_6_temperature_type5;
    server.robotInfo.server_humidity = msg->server_6_humidity_type5;
    server.robotInfo.server_pressure = msg->server_6_pressure_type5;
    server.robotInfo.server_o2 = msg->server_6_o2_type5;
    server.robotInfo.server_tvoc = msg->server_6_tvoc_type5;
    server.robotInfo.server_pm25 = msg->server_6_pm25_type5;

//    cout<<"receive a msg"<<endl;
}

void lidarCallback(const sensor_msgs::LaserScan::ConstPtr& msg)
{   
    server.robotInfo.angle_min = msg->angle_min;
    server.robotInfo.angle_max = msg->angle_max;
    server.robotInfo.angle_increment = msg->angle_increment;
    server.robotInfo.time_increment = msg->time_increment;
    server.robotInfo.scan_time = msg->scan_time;
    server.robotInfo.range_min = msg->range_min;
    server.robotInfo.range_max = msg->range_max;
    for(int i = 0; i < 1035; i++)
    {
        server.robotInfo.ranges[i] = msg->ranges[i];
    }
}

void bmsCallback(const trans_drive::BatteryConstPtr& msg)
{
    server.robotInfo.batteryPercentage = msg->rsoc;
    server.robotInfo.batteryValue = msg->voltage / 1000.0;

    server.robotInfo.batteryCharging = msg->ischarging;

    if(msg->ischarging == 1)
    {
        server.robotInfo.batteryCharging = true;
    }else if(msg->ischarging == 0)
    {
        server.robotInfo.batteryCharging = false;
    }
}

void aircleanerCallback(const std_msgs::Int8::ConstPtr& msg)
{
    server.robotInfo.isOpenedAirCleaner = msg->data;
//    if(msg->data == 1)
//    {
//        server.robotInfo.isOpenedAirCleaner = true;
//    }else if(msg->data == 0)
//    {
//        server.robotInfo.isOpenedAirCleaner = false;
//    }
}

void positionCallback(const geometry_msgs::PoseWithCovarianceStamped::ConstPtr& msg)
{
    server.robotInfo.positionX = msg->pose.pose.position.x;
    server.robotInfo.positionY = msg->pose.pose.position.y;
    float x = msg->pose.pose.orientation.x;
    float y = msg->pose.pose.orientation.y;
    float z = msg->pose.pose.orientation.z;
    float w = msg->pose.pose.orientation.w;
    server.robotInfo.positionTheta = atan2( 2 * ( x * y + w * z ), w * w + x * x - y * y - z * z );
    // server.robotInfo.speedLinear = ;
    // server.robotInfo.speedAngular = msg->twist.twist.angular.z;
}

void navigationCallback(const youi_bridge::NavigationStatus::ConstPtr& msg)
{

}

void pictureCallback(const std_msgs::Int8::ConstPtr& msg)
{
    server.takePicture = msg->data;
    cout<< msg->data <<endl;
}

int main(int argc, char* argv[]) {

    server.startT();

    ros::init(argc,argv,"youi_bridge");
    ros::NodeHandle nh;
    ros::Rate loop_rate(5);


    // subscribe robotInfo 
    ros::Subscriber lidar_sub = nh.subscribe("/scan",1,&lidarCallback);
    // subscribe ilems server sensors data
    // ros::Subscriber ilems_sub = nh.subscribe("/sensor_http_topic",10,&sensorCallback);
    // subscribe bms
    ros::Subscriber bms_sub = nh.subscribe("/bms_data",10,&bmsCallback);
    // subscribe if air cleaner is openned
    // ros::Subscriber aircleaner_sub = nh.subscribe("/aircleaner_open",10,&aircleanerCallback);
    // subscribe position msg
    ros::Subscriber position_sub = nh.subscribe("/amcl_pose",10,&positionCallback);
    // subscribe navigation msg
    ros::Subscriber goal_sub = nh.subscribe("/status",10,&navigationCallback);
    // subscribe take picture msg
    // ros::Subscriber picture_sub = nh.subscribe("/take_picture_topic",10,&pictureCallback);
   

//    // publish aircleaner control cmd
//    ros::Publisher aircleaner_pub = nh.advertise<std_msgs::Int8>("how_about_aircleaner",10);

//    while(ros::ok())
//    {
//        ros::spinOnce();
//        if(server.operator_airCleaner == 1 && server.robotInfo.isOpenedAirCleaner == false)
//        {
//            std_msgs::Int8 m;
//            m.data = 1;
//            aircleaner_pub.publish(m);
//            cout<<"open"<<endl;
//        }else if(server.operator_airCleaner == 0 && server.robotInfo.isOpenedAirCleaner == true)
//        {
//            std_msgs::Int8 m;
//            m.data = 0;
//            aircleaner_pub.publish(m);
//            cout<<"close"<<endl;
//        }


//        loop_rate.sleep();
//    }

    ros::spin();
    return 0;
}
