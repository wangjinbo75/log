#include "broadcaster_server.h"
#define MapPgmPath "/home/youibot/catkin_ws/src/youi_navigation/map/firstMap.pgm"
#define MapYamlPath "/home/youibot/catkin_ws/src/youi_navigation/map/firstMap.yaml"
void telemetry_server::startT()
{
    // 开启线程
    int ret = start();
    if(ret == 0)
    {
        cout<<"Create Websocket pthread successfully!"<<endl;
    }
}

int telemetry_server::start()
{
    if(pthread_create(&pid,NULL,start_thread,(void *)this) != 0) //´创建一个线程(必须是全局函数)
    {
        return -1;
    }
    return 0;
}

void* telemetry_server::start_thread(void *arg)
{
    telemetry_server *ptr = (telemetry_server *)arg;

    ptr->startWorking();
}

void telemetry_server::startWorking()
{
    readYamlFile();
    // set up access channels to only log interesting things
    m_endpoint.clear_access_channels(websocketpp::log::alevel::all);
    m_endpoint.set_access_channels(websocketpp::log::alevel::access_core);
    m_endpoint.set_access_channels(websocketpp::log::alevel::app);

//        m_endpoint.set_access_channels(websocketpp::log::alevel::all);
//        m_endpoint.clear_access_channels(websocketpp::log::alevel::frame_payload);

    // Initialize the Asio transport policy
    m_endpoint.init_asio();

    // Bind the handlers we are using
    using websocketpp::lib::placeholders::_1;
    using websocketpp::lib::bind;

    m_endpoint.set_open_handler(bind(&telemetry_server::on_open,this,_1));
    m_endpoint.set_close_handler(bind(&telemetry_server::on_close,this,_1));
//        m_endpoint.set_http_handler(bind(&telemetry_server::on_http,this,_1));

    m_endpoint.set_ping_handler(
                [](connection_hdl hdl,string str)-> bool{
        cout<<"ping: "<<hdl.lock()<<endl;
        cout<<str<<endl;
        return true;
    });

    m_endpoint.set_message_handler(
                [&](connection_hdl hdl,message_ptr msg){
        cout<<"message: "<<hdl.lock()<<endl;
        cout<<msg->get_payload()<<endl;
        Json::Value readFrom;
        reader.parse(msg->get_payload(),readFrom);
        cout<< readFrom.toStyledString() <<endl;
        int ret = handleMessageFromClient(readFrom,hdl);
        if(ret == 0)
        {
            cout<< "Handle the message successfully!" <<endl;
        }else
        {
            cout<< "Occur some error!" <<endl;
        }
    });

    std::string docroot = "/var/www/html";
    uint16_t port = PORT;
    run(docroot, port);
}

void telemetry_server::fuzhi(RobotInfo info)
{
    memcpy(&robotInfo,&info,sizeof(info));

    root = updateRobotInfoJson();

    cout<<robotInfo.server_dish_temp_1<<" "<<robotInfo.server_dish_temp_2<<endl;

    ostringstream oss;
    oss<< this_thread::get_id();
    string stid = oss.str();
    unsigned long long tid = stoull(stid);
    cout<< "thread id : " << tid << endl;
}

Json::Value telemetry_server::readJsonFile()
{
    std::ifstream ifs(ROBOTINFO_JSON);//open file robotinfo.json
    if(sizeof(ifs) < 10)
    {
        std::cout<<"robotinfo.json is empty!"<<std::endl;
    }
    if(!reader.parse(ifs, root)){
       // fail to parse
        std::cout<<"robotinfo.json convert Filed!"<<std::endl;
    }else
    {
        return root;
    }
    return root;
}

void telemetry_server::readYamlFile()
{
    Json::Value wayjson;

    std::ifstream ifs(WAYPOINTS_YAML);
    if(sizeof(ifs) < 10)
    {
        std::cout<<"waypoints.json is empty!"<<std::endl;
    }
    if(!reader.parse(ifs, wayjson))
    {
        std::cout<<"waypoints.json convert Filed!"<<std::endl;
    }else{
        int length = boost::size(wayjson["positionName"]);
        cout<<length<<endl;

        waypoints.resize(length);
        robotPose.resize(length);

        for(int i = 0 ; i < length ; i++)
        {
            waypoints[i] = wayjson["positionName"][i]["name"].asCString();
            RobotPose rp;
            rp.px = wayjson["positionName"][i]["px"].asFloat();
            rp.py = wayjson["positionName"][i]["py"].asFloat();
            rp.pz = wayjson["positionName"][i]["pz"].asFloat();
            rp.ox = wayjson["positionName"][i]["ox"].asFloat();
            rp.oy = wayjson["positionName"][i]["oy"].asFloat();
            rp.oz = wayjson["positionName"][i]["oz"].asFloat();
            rp.ow = wayjson["positionName"][i]["ow"].asFloat();
            robotPose[i] = rp;
//            cout<<robotPose[i].px<<endl;
        }
    }
}

Json::Value telemetry_server::updateRobotInfoJson()
{
    /*
     * {
        "name": "AllData",
        "message": {
            "voltageTotal": 27.6,
            "batteryValue": 15,
            "batteryPercentage": 100,
            "batteryCharging": true,
            "speedLinear": 0.5,
            "speedAngular": 1.0,
            "isOpenedAirCleaner": false,
            "positionInMap": {
                "x": 23.4,
                "y": 34.5,
                "z": 0.0,
                "theta": 3.14159
            },
            "navigationTarget": {
                "goal": "P1",
                "goalStatus": 1,
                "errorMsg": "DWA plan failed"
            },
            "robotSensors": [
                {"keyname": "temperature", "keyvalue": 27},
                {"keyname": "humidity", "keyvalue": 34},
                {"keyname": "pressure", "keyvalue": 800},
                {"keyname": "o2", "keyvalue": 21},
                {"keyname": "tvoc", "keyvalue": 10},
                {"keyname": "pm25", "keyvalue": 34}
            ],
            "serverSensors": [
                {"keyname": "temperature", "keyvalue": 27},
                {"keyname": "humidity", "keyvalue": 34},
                {"keyname": "pressure", "keyvalue": 800},
                {"keyname": "o2", "keyvalue": 21},
                {"keyname": "tvoc", "keyvalue": 10},
                {"keyname": "pm25", "keyvalue": 34},
                {"keyname": "n2", "keyvalue": -196},
                {"keyname": "wireless_o2", "keyvalue": 21},
                {"keyname": "seal_co2", "keyvalue": 6.1},
                {"keyname": "non_seal_co2", "keyvalue": 6.2},
                {"keyname": "dish_temp_1", "keyvalue": 36.9},
                {"keyname": "dish_temp_2", "keyvalue": 36.8},
                {"keyname": "dish_temp_3", "keyvalue": 36.7},
                {"keyname": "dish_temp_4", "keyvalue": 36.6},
                {"keyname": "dish_temp_5", "keyvalue": 36.5},
                {"keyname": "dish_temp_6", "keyvalue": 36.4},
                {"keyname": "dish_temp_7", "keyvalue": 36.3},
                {"keyname": "dish_temp_8", "keyvalue": 36.2}
            ]
        }
    }
     */
    Json::Value js;
    Json::Value root;
    js["name"] = "AllData";
    // serverSensors
    Json::Value serverSensor;
    serverSensor[0]["keyname"] = "temperature";
    serverSensor[0]["keyvalue"] = robotInfo.server_temperature;
    serverSensor[1]["keyname"] = "humidity";
    serverSensor[1]["keyvalue"] = robotInfo.server_humidity;
    serverSensor[2]["keyname"] = "pressure";
    serverSensor[2]["keyvalue"] = robotInfo.server_pressure;
    serverSensor[3]["keyname"] = "o2";
    serverSensor[3]["keyvalue"] = robotInfo.server_o2;
    serverSensor[4]["keyname"] = "tvoc";
    serverSensor[4]["keyvalue"] = robotInfo.server_tvoc;
    serverSensor[5]["keyname"] = "pm25";
    serverSensor[5]["keyvalue"] = robotInfo.server_pm25;
    serverSensor[6]["keyname"] = "n2";
    serverSensor[6]["keyvalue"] = robotInfo.server_n2;
    serverSensor[7]["keyname"] = "wireless_o2";
    serverSensor[7]["keyvalue"] = robotInfo.server_wireless_o2;
    serverSensor[8]["keyname"] = "seal_co2";
    serverSensor[8]["keyvalue"] = robotInfo.server_seal_co2 / 10000.0;
    serverSensor[9]["keyname"] = "non_seal_co2";
    serverSensor[9]["keyvalue"] = robotInfo.server_non_seal_co2 / 10000.0;
    serverSensor[10]["keyname"] = "dish_temp_1";
    serverSensor[10]["keyvalue"] = robotInfo.server_dish_temp_1;
//    cout<< serverSensor[10]["keyvalue"]<<endl;
    serverSensor[11]["keyname"] = "dish_temp_2";
    serverSensor[11]["keyvalue"] = robotInfo.server_dish_temp_2;
    serverSensor[12]["keyname"] = "dish_temp_3";
    serverSensor[12]["keyvalue"] = robotInfo.server_dish_temp_3;
    serverSensor[13]["keyname"] = "dish_temp_4";
    serverSensor[13]["keyvalue"] = robotInfo.server_dish_temp_4;
    serverSensor[14]["keyname"] = "dish_temp_5";
    serverSensor[14]["keyvalue"] = robotInfo.server_dish_temp_5;
    serverSensor[15]["keyname"] = "dish_temp_6";
    serverSensor[15]["keyvalue"] = robotInfo.server_dish_temp_6;
    serverSensor[16]["keyname"] = "dish_temp_7";
    serverSensor[16]["keyvalue"] = robotInfo.server_dish_temp_7;
    serverSensor[17]["keyname"] = "dish_temp_8";
    serverSensor[17]["keyvalue"] = robotInfo.server_dish_temp_8;
    // robotSensors
    Json::Value robotSensor;
    robotSensor[0]["keyname"] = "temperature";
    robotSensor[0]["keyvalue"] = robotInfo.robot_temperature;
    robotSensor[1]["keyname"] = "humidity";
    robotSensor[1]["keyvalue"] = robotInfo.robot_humidity;
    robotSensor[2]["keyname"] = "pressure";
    robotSensor[2]["keyvalue"] = robotInfo.robot_pressure;
    robotSensor[3]["keyname"] = "o2";
    robotSensor[3]["keyvalue"] = robotInfo.robot_o2;
    robotSensor[4]["keyname"] = "tvoc";
    robotSensor[4]["keyvalue"] = robotInfo.robot_tvoc;
    robotSensor[5]["keyname"] = "pm25";
    robotSensor[5]["keyvalue"] = robotInfo.robot_pm25;
    robotSensor[6]["keyname"] = "lidarData";
    // lidarData
    Json::Value lidarData;
    lidarData[0]["keyname"] = "angle_min";
    lidarData[0]["keyvalue"] = robotInfo.angle_min;
    lidarData[1]["keyname"] = "angle_max";
    lidarData[1]["keyvalue"] = robotInfo.angle_max;
    lidarData[2]["keyname"] = "angle_increment";
    lidarData[2]["keyvalue"] = robotInfo.angle_increment;
    lidarData[3]["keyname"] = "time_increment";
    lidarData[3]["keyvalue"] = robotInfo.time_increment;
    lidarData[4]["keyname"] = "scan_time";
    lidarData[4]["keyvalue"] = robotInfo.scan_time;
    lidarData[5]["keyname"] = "range_min";
    lidarData[5]["keyvalue"] = robotInfo.range_min;
    lidarData[6]["keyname"] = "range_max";
    lidarData[6]["keyvalue"] = robotInfo.range_max;
    lidarData[7]["keyname"] = "ranges";
    for(int i = 0; i < 1035; i++)
    {
        lidarData[7]["keyvalue"][i] = robotInfo.ranges[i];
    }
    // navigationTarget
    Json::Value navigationTarget;
    navigationTarget["goal"] = robotInfo.goal;
    navigationTarget["goalStatus"] = robotInfo.goalStatus;
    navigationTarget["errorMsg"] = robotInfo.errorMsg;
    // positionInMap
    Json::Value positionInMap;
    positionInMap["x"] = robotInfo.positionX;
    positionInMap["y"] = robotInfo.positionY;
    positionInMap["z"] = robotInfo.positionZ;
    positionInMap["theta"] = robotInfo.positionTheta;

    Json::Value message;
    // message["isOpenedAirCleaner"] = robotInfo.isOpenedAirCleaner;
    // message["speedAngular"] = robotInfo.speedAngular;
    // message["speedLinear"] = robotInfo.speedLinear;
    message["batteryCharging"] = robotInfo.batteryCharging;
    message["batteryPercentage"] = robotInfo.batteryPercentage;
    message["batteryValue"] = robotInfo.batteryValue;
    message["voltageTotal"] = robotInfo.voltageTotal;
    // message["robotSensors"] = robotSensor;
    // message["serverSensor"] = serverSensor;
    // message["navigationTarget"] = navigationTarget;
    message["positionInMap"] = positionInMap;
    message["lidarData"] = lidarData;

    js["message"] = message;

    //cout<<"robotInfo: "<<robotInfo.voltageTotal<<endl;

//    cout<<"update json: "<<robotInfo.server_dish_temp_1<<" "<<robotInfo.server_dish_temp_2<<endl;
//    ostringstream oss;
//    oss<< this_thread::get_id();
//    string stid = oss.str();
//    unsigned long long tid = stoull(stid);
//    cout<< "thread id update json : " << tid << endl;
//    cout<<js.toStyledString()<<endl;

    return js;
}

int telemetry_server::handleMessageFromClient(Json::Value json, connection_hdl hdl)
{
    Json::Value jj;
    Json::Value mapdata;
    con_list::iterator it;
    stringstream ss;
    string imgBase64;
    string str;
    string positionName;
    youi_bridge::WayPoints nav_msg;
    geometry_msgs::Pose nav_pose;
    youi_bridge::WebMove web_move_msg;
    int len;

    switch (s_mapStringCalues[json["name"].asCString()]) {

    case robotMove:
        cout<<"robotMove!"<<endl;
        web_move_msg.goStraight = json["message"]["goStraight"].asInt();
        web_move_msg.goTurn = json["message"]["goTurn"].asInt();
        web_move_msg.stop = json["message"]["stop"].asInt();
        web_move_msg.max_linear_x = json["message"]["max_linear_x"].asFloat();
        web_move_msg.max_angular_z = json["message"]["max_angular_z"].asFloat();
        robotMove_pub.publish(web_move_msg);
        break;

    case setCleaner:
        cout<<"control the air cleaner!"<<endl;
        if(json["status"] == "on")

        {
            operator_airCleaner = 1;
            std_msgs::Int8 msg;
            msg.data = operator_airCleaner;
            aircleaner_pub.publish(msg);
        }

        if(json["status"] == "off")
        {
            operator_airCleaner = 0;
            std_msgs::Int8 msg;
            msg.data = operator_airCleaner;
            aircleaner_pub.publish(msg);
        }

        break;

    case gotoPosition:
        cout<<"go to some position!"<<endl;

        // point to point navigation
        positionName = json["position"].asCString();
        cout<<positionName<<endl;
        if(positionName == "cancel")
        {
            nav_msg.cancel = 1;
            nav_msg.ways = 2;
            navigation_pub.publish(nav_msg);
        }else{
            nav_msg.cancel = 0;
            nav_msg.ways = 0;
            len = boost::size(waypoints);
            for(int i =0;i< len;i++)
            {
                if(positionName == waypoints[i])
                {
                    nav_pose.position.x = robotPose[i].px;
                    nav_pose.position.y = robotPose[i].py;
                    nav_pose.position.z = robotPose[i].pz;
                    nav_pose.orientation.x = robotPose[i].ox;
                    nav_pose.orientation.y = robotPose[i].oy;
                    nav_pose.orientation.z = robotPose[i].oz;
                    nav_pose.orientation.w = robotPose[i].ow;
                    nav_msg.poses.poses.resize(1);
                    nav_msg.poses.poses[0] = nav_pose;
                    navigation_pub.publish(nav_msg);
                }
            }
        }
        break;
    case gotoCharging:
        cout<<"go to charging!"<<endl;
        break;
    
    case getMap:
        cout<<"send Map data!"<<endl;

        cv::Mat img= cv::imread(MapPgmPath);
        std::vector<unsigned char> data_encode;
        int res = cv::imencode(".jpg", img, data_encode);
        std::string str_encode(data_encode.begin(), data_encode.end());
        const char* c = (char*)str_encode.c_str();
        imgBase64 = websocketpp::base64_encode((unsigned char*)c, str_encode.size());
        cout<<imgBase64<<endl;
        cout << "img base64 encode size:" << imgBase64.size() << endl;      
        // string imgdecode64 = websocketpp::base64_decode(imgBase64);
        // cout << "img decode size:" << imgdecode64.size() << endl; 
        // cout << imgdecode64<<endl;

        YAML::Node map_yaml = YAML::LoadFile(MapYamlPath);
        const std::string image = map_yaml["image"].as<std::string>();
        const std::string resolution = map_yaml["resolution"].as<std::string>();
        const std::string origin_x = map_yaml["origin"][0].as<std::string>();
        const std::string origin_y = map_yaml["origin"][1].as<std::string>();
        const std::string origin_z = map_yaml["origin"][2].as<std::string>();
        const std::string negate = map_yaml["negate"].as<std::string>();
        const std::string occupied_thresh = map_yaml["occupied_thresh"].as<std::string>();
        const std::string free_thresh = map_yaml["free_thresh"].as<std::string>();
    
        mapdata["map"] = imgBase64;
        mapdata["yaml"]["image"] = image;
        mapdata["yaml"]["resolution"] = resolution;
        mapdata["yaml"]["origin_x"] = origin_x;
        mapdata["yaml"]["origin_y"] = origin_y;
        mapdata["yaml"]["origin_z"] = origin_z;
        mapdata["yaml"]["negate"] = negate;
        mapdata["yaml"]["occupied_thresh"] = occupied_thresh;
        mapdata["yaml"]["free_thresh"] = free_thresh;

        str = mapdata.toStyledString();
        ss << str;
        for (it = m_connections.begin(); it != m_connections.end(); ++it) 
        {
            m_endpoint.send(*it,ss.str(),websocketpp::frame::opcode::text);
        }
    // default:
    //     cout<<"No right header!"<<endl;
    //     break;
    }
    return 0;

}

void telemetry_server::run(std::__cxx11::string docroot, uint16_t port)
{
    std::stringstream ss;
    ss << "Running telemetry server on port "<< port <<" using docroot=" << docroot;
    m_endpoint.get_alog().write(websocketpp::log::alevel::app,ss.str());

    m_docroot = docroot;

    // listen on specified port
    m_endpoint.listen(port);

    // Start the server accept loop
    m_endpoint.start_accept();

    // Set the initial timer to start telemetry
    set_timer();

    // Start the ASIO io_service run loop
    try {
        m_endpoint.run();
    } catch (websocketpp::exception const & e) {
        std::cout << e.what() << std::endl;
    }
}

void telemetry_server::set_timer()
{
    m_timer = m_endpoint.set_timer(
        1000,
        websocketpp::lib::bind(
            &telemetry_server::on_timer,
            this,
            websocketpp::lib::placeholders::_1
        )
    );
}

void telemetry_server::on_timer(const std::error_code &ec)
{
    if (ec) {
        // there was an error, stop telemetry
        m_endpoint.get_alog().write(websocketpp::log::alevel::app,
                "Timer Error: "+ec.message());
        return;
    }

    ros::spinOnce();

    std::stringstream val;
    Json::Value json = updateRobotInfoJson();

    json.toStyledString();
    std::string out = json.toStyledString();
    val << out;

    con_list::iterator it;
    for (it = m_connections.begin(); it != m_connections.end(); ++it) {
        m_endpoint.send(*it,val.str(),websocketpp::frame::opcode::text);
        if(takePicture == 1)
        {
            std::stringstream outstr;
            std::string outt = takePictureJson.toStyledString();
            cout<< outt <<endl;
            outstr << outt;
            m_endpoint.send(*it,outstr.str(),websocketpp::frame::opcode::text);
        }
//        cout<<json["serverSensor"][10]["keyname"]<<" "<<json["serverSensor"][10]["keyvalue"]<<endl;
    }
    takePicture = 0;

    // set timer for next telemetry check
    set_timer();
}

void telemetry_server::on_http(connection_hdl hdl)
{
    // Upgrade our connection handle to a full connection_ptr
    server::connection_ptr con = m_endpoint.get_con_from_hdl(hdl);

    std::ifstream file;
    std::string filename = con->get_resource();
    std::string response;

    m_endpoint.get_alog().write(websocketpp::log::alevel::app,
        "http request1: "+filename);

    if (filename == "/") {
        filename = m_docroot+"index.html";
    } else {
        filename = m_docroot+filename.substr(1);
    }

    m_endpoint.get_alog().write(websocketpp::log::alevel::app,
        "http request2: "+filename);

    file.open(filename.c_str(), std::ios::in);
    if (!file) {
        // 404 error
        std::stringstream ss;

        ss << "<!doctype html><html><head>"
           << "<title>Error 404 (Resource not found)</title><body>"
           << "<h1>Error 404</h1>"
           << "<p>The requested URL " << filename << " was not found on this server.</p>"
           << "</body></head></html>";

        con->set_body(ss.str());
        con->set_status(websocketpp::http::status_code::not_found);
        return;
    }

    file.seekg(0, std::ios::end);
    response.reserve(file.tellg());
    file.seekg(0, std::ios::beg);

    response.assign((std::istreambuf_iterator<char>(file)),
                    std::istreambuf_iterator<char>());

    con->set_body(response);
    con->set_status(websocketpp::http::status_code::ok);
}
