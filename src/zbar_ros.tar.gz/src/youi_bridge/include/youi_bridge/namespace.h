#ifndef __NAMESPACE_H__
#define __NAMESPACE_H__

#include <iostream>
#include <stdio.h>
#include <stdint.h>
#include <string>
#include <ctime>

// websocket监听的网络端口
#define PORT 9009
#define ROBOTINFO_JSON "/home/youibot/catkin_ws/src/youi_bridge/inlems_app_settings.json"
#define WAYPOINTS_YAML "/home/youibot/catkin_ws/src/youi_bridge/waypoints.json"

using namespace std;


/* General types */
typedef  uint8_t     boolean;
typedef  int8_t      int8;
typedef  int16_t     int16;
typedef  int32_t     int32;
typedef  uint8_t     uint8;
typedef  uint16_t    uint16;
typedef  uint32_t    uint32;
typedef  int64_t     int64;
typedef  uint64_t    uint64;
typedef  float       float32;
typedef  double      float64;



/** 命名空間 **/

namespace youi_bridge_namespace {

    /** struct of robotInfo **/
    typedef struct
    {
        // voltage total
        float32 voltageTotal;
        // battery voltage current
        float32 batteryValue;
        // battery percentage
        float32 batteryPercentage;
        // battery charging
        int8 batteryCharging;
        // linear speed
        float32 speedLinear;
        // angular speed
        float32 speedAngular;
        // position in map
        float32 positionX;
        float32 positionY;
        float32 positionZ;
        float32 positionTheta;
        // navigation Target
        string goal;
        int8 goalStatus;
        string errorMsg;
        // robot sensors
        float32 robot_temperature;
        float32 robot_humidity;
        float32 robot_pressure;
        float32 robot_o2;
        float32 robot_tvoc;
        float32 robot_pm25;
        // server sensors
        float32 server_temperature;
        float32 server_humidity;
        float32 server_pressure;
        float32 server_o2;
        float32 server_tvoc;
        float32 server_pm25;
        float32 server_n2;
        float32 server_wireless_o2;
        float32 server_seal_co2;
        float32 server_non_seal_co2;
        float32 server_dish_temp_1;
        float32 server_dish_temp_2;
        float32 server_dish_temp_3;
        float32 server_dish_temp_4;
        float32 server_dish_temp_5;
        float32 server_dish_temp_6;
        float32 server_dish_temp_7;
        float32 server_dish_temp_8;
        // isOpenedAirCleaner
        int8 isOpenedAirCleaner;
        // lidarData
        float32 angle_min;
        float32 angle_max;
        float32 angle_increment;
        float32 time_increment;
        float32 scan_time;
        float32 range_min;
        float32 range_max;
        float32 ranges[1035];

    } RobotInfo;

    /** struct of pose **/
    typedef struct
    {
        float32 px;
        float32 py;
        float32 pz;
        float32 ox;
        float32 oy;
        float32 oz;
        float32 ow;
    } RobotPose;
}
#endif
