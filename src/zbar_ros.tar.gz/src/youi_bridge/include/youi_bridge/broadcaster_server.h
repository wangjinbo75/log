#ifndef __BROADCASTER_SERVER_H__
#define __BROADCASTER_SERVER_H__

#include <websocketpp/config/asio_no_tls.hpp>

#include <websocketpp/server.hpp>
#include <websocketpp/base64/base64.hpp>

#include <jsoncpp/json/json.h>

#include <fstream>
#include <iostream>
#include <set>
#include <streambuf>
#include <string>
#include <functional>
#include <map>
#include <vector>
#include "namespace.h"
#include <yaml-cpp/yaml.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

#include "ros/ros.h"
#include "std_msgs/Int32MultiArray.h"
#include "std_msgs/Int8.h"
#include "InlemsSensor.h"
#include "AutoNavigation.h"
#include "WayPoints.h"
#include "WebMove.h"
#include "NavigationStatus.h"
#include "geometry_msgs/Pose.h"

using namespace std;
using namespace cv;
using namespace youi_bridge_namespace;

//typedef websocketpp::server<websocketpp::config::asio> server;
//typedef server::message_ptr message_ptr;

class telemetry_server {

public:

    /** 包括一些json对象 **/
    Json::Value root;
    Json::Reader reader;
    /**截屏命令**/
    Json::Value takePictureJson;
    /** 地图发布数据JSON **/
    Json::Value mapJson;
    /** RobotInfo **/
    RobotInfo robotInfo;

    enum StringValue{
        setCleaner,
        gotoPosition,
        gotoCharging,
        robotMove,
        getMap
    };

    map<string,StringValue> s_mapStringCalues;

    // 操作空气净化器标志位
    int8_t operator_airCleaner;
    // 路径点名称
    vector<string> waypoints;
    // 路径点的信息
    vector<RobotPose> robotPose;
    // 是否需要拍照的记录位1:拍照 0:不拍照
    int8_t takePicture;

public:

    int countt ;

    // 新建一个线程
    pthread_t pid;
    static void * start_thread(void* arg);// //静态成员函数
    int start();

    ros::Publisher aircleaner_pub;
    ros::Publisher navigation_pub;
    ros::Publisher robotMove_pub;

    // 连接句柄
    typedef websocketpp::connection_hdl connection_hdl;
    typedef websocketpp::server<websocketpp::config::asio> server;
    typedef server::message_ptr message_ptr;
    typedef server::message_handler message_handler;

    telemetry_server()
    {
        s_mapStringCalues["setCleaner"] = setCleaner;
        s_mapStringCalues["gotoPosition"] = gotoPosition;
        s_mapStringCalues["goCharging"] = gotoCharging;
        s_mapStringCalues["getMap"] = getMap;
        s_mapStringCalues["robotMove"] = robotMove;

        operator_airCleaner = 66;
        countt = 0;
        takePicture = 66;

        // init robotInfo
        robotInfo.batteryCharging = 0;
        robotInfo.isOpenedAirCleaner = 0;
        robotInfo.batteryPercentage = 0;
        robotInfo.batteryValue = 0;
        robotInfo.errorMsg = "No Updated";
        robotInfo.goal = "P1";
        robotInfo.goalStatus = 1;
        robotInfo.positionTheta = 90.5;
        robotInfo.positionX = 3.4;
        robotInfo.positionY = 2.3;
        robotInfo.positionZ = 0.0;
        robotInfo.robot_humidity = 22;
        robotInfo.robot_o2 = 22;
        robotInfo.robot_pm25 = 22;
        robotInfo.robot_pressure = 23;
        robotInfo.robot_temperature = 22;
        robotInfo.robot_tvoc = 22;
        robotInfo.speedAngular = 0.2;
        robotInfo.speedLinear = 0.2;
        robotInfo.server_dish_temp_1 = 0;
        robotInfo.server_dish_temp_2 = 0;
        robotInfo.server_dish_temp_3 = 0;
        robotInfo.server_dish_temp_4 = 0;
        robotInfo.server_dish_temp_5 = 0;
        robotInfo.server_dish_temp_6 = 0;
        robotInfo.server_dish_temp_7 = 0;
        robotInfo.server_dish_temp_8 = 0;
        robotInfo.server_humidity = 0;
        robotInfo.server_n2 = 0;
        robotInfo.server_non_seal_co2 = 0;
        robotInfo.server_o2 = 0;
        robotInfo.server_pm25 = 0;
        robotInfo.server_pressure = 0;
        robotInfo.server_seal_co2 = 0;
        robotInfo.server_temperature = 0;
        robotInfo.server_tvoc = 0;
        robotInfo.server_wireless_o2 = 0;
        robotInfo.voltageTotal = 54.6;

        // takepicturejson初始化
        takePictureJson["name"] = "screenShot";
        takePictureJson["position"] = "位置";

        cout<<"gou zao han shu : "<<robotInfo.server_dish_temp_1<<" "<<robotInfo.server_dish_temp_2<<endl;

        int argc = 0;

        char* argv[2] = {0};

        ros::init(argc,argv,"youi_server");
        ros::NodeHandle h;
        // publish aircleaner control cmd
        //aircleaner_pub = h.advertise<std_msgs::Int8>("how_about_aircleaner",10);

        //navigation_pub = h.advertise<youi_bridge::WayPoints>("/position",10);

        robotMove_pub = h.advertise<youi_bridge::WebMove>("/WebMove",10);
    }

    // 读取json数据
    Json::Value readJsonFile();

    // 初始化json数据
    Json::Value updateRobotInfoJson();

    // 读取yaml文件
    void readYamlFile();

    void startWorking();

    void startT();

    void fuzhi(RobotInfo info);

    void run(std::string docroot, uint16_t port);

    void set_timer();

    /** deal with the json from client **/
    int  handleMessageFromClient(Json::Value json,connection_hdl hdl);

    void on_timer(websocketpp::lib::error_code const & ec);

    void on_http(connection_hdl hdl);

    void on_open(connection_hdl hdl) {
        m_connections.insert(hdl);
    }

    void on_close(connection_hdl hdl) {
        m_connections.erase(hdl);
    }

private:
    // 需要增加C++ 11 标准
    typedef std::set<connection_hdl,std::owner_less<connection_hdl>> con_list;

    server m_endpoint;
    message_handler h;
    con_list m_connections;
    server::timer_ptr m_timer;

    std::string m_docroot;

    // Telemetry data
    uint64_t m_count;

};

#endif
