#include "ros/ros.h"
#include <iostream>
#include "geometry_msgs/PoseWithCovarianceStamped.h"
#include "geometry_msgs/Twist.h"
#include "geometry_msgs/TwistWithCovariance.h"
#include "nav_msgs/Odometry.h"
#include <tf/transform_broadcaster.h>

using namespace std;

nav_msgs::Odometry ekfMsgs;

void odomCombineCallback(const geometry_msgs::PoseWithCovarianceStampedConstPtr& msg)
//void odomCombineCallback(const nav_msgs::OdometryConstPtr& msg)
{
    ekfMsgs.pose = msg->pose;
    double x = msg->pose.pose.orientation.x;
    double y = msg->pose.pose.orientation.y;
    double z = msg->pose.pose.orientation.z;
    double w = msg->pose.pose.orientation.w;
    double angle = atan2(2 * (x * y + w * z), w * w + x * x - y * y - z * z) * 180 / 3.1415926;
    //ROS_INFO("angle = %f", angle);
}

void speedCallback(const geometry_msgs::TwistWithCovarianceConstPtr& msg)
{
    ekfMsgs.twist.twist.linear.x = msg->twist.linear.x;
    ekfMsgs.twist.twist.angular.z = msg->twist.angular.z;
    ekfMsgs.twist.covariance = msg->covariance;
}

int main(int argc,char** argv)
{
    ros::init(argc,argv,"transform_odom");
    ros::NodeHandle nh;
    ros::Rate loop_rate(50);
    /** 订阅/odom_combain话题 **/
    ros::Subscriber odom_combine_sub = nh.subscribe("odom_combined",1000,&odomCombineCallback); //odom_combined
    /** 订阅speedT_wheel话题 **/
    ros::Subscriber speed_sub = nh.subscribe("speedT_wheel",1000,&speedCallback);
    /** 发布里程计命令 **/
    ros::Publisher odom_ekf_pub = nh.advertise<nav_msgs::Odometry>("odom_ekf",1000);

    ekfMsgs.header.frame_id = "odom_ekf";
    ekfMsgs.child_frame_id = "base_footprint";

    while (ros::ok()) {
        ros::spinOnce();

        ekfMsgs.header.stamp = ros::Time::now();

        odom_ekf_pub.publish(ekfMsgs);

        loop_rate.sleep();
    }

    return 0;
}
