#include <cmath>
#include <ros/ros.h>
#include <tf/tf.h>
#include <std_msgs/Int8.h>
#include <std_msgs/Int16MultiArray.h>
#include <std_msgs/Int32MultiArray.h>
#include <std_msgs/Int64MultiArray.h>
#include <std_msgs/Float32.h>
#include <std_msgs/Bool.h>
#include <geometry_msgs/Twist.h>
#include <sensor_msgs/Imu.h>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/TwistWithCovariance.h>
#include <motion.h>
#include "imu.h"
#include "bms.h"
#include "msgs/Battery.h"

// stm32串口对象
InfraredSerial infrared_serial;
// 电池bms串口对象
BMS bms(BMS_DEV);
// IMU串口对象
IMU imu;
short out_left = 0;
short out_right = 0;
float kp = 0.6;
void velocityCallback(const std_msgs::Int16MultiArray::ConstPtr &msg)
{
    short left_velocity = msg->data[0];
    short right_velocity = msg->data[1];
    short left = REDUCTION * 60 / (M_PI * DIAMETER / 1000) * left_velocity / 100;
    short right = REDUCTION * 60 / (M_PI * DIAMETER / 1000) * right_velocity / 100;
    out_left += (left-out_left)*kp;
    out_right += (right-out_right)*kp;
    infrared_serial.send_velocity.motor_left = out_left;
    infrared_serial.send_velocity.motor_right = out_right;
    //infrared_serial.uart_write_origin(left_velocity, right_velocity);
    //ROS_INFO("writing %d %d",out_left,out_right);
}

void relayCallback(const std_msgs::Bool msg)
{
    if (msg.data == true)
    {
        infrared_serial.relay_flag = 1;
    }
    else
    {
        infrared_serial.relay_flag = 0;
    }
    //ROS_INFO("writing %d %d",left_velocity,right_velocity);
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "mobile_base");
    ros::NodeHandle nh;
    ros::Rate loop_rate(40);

    /**下位机心跳报文**/
    ros::Publisher heartbeat_message_pub = nh.advertise<std_msgs::Int16MultiArray>("/heartbeat_messasge", 100);
    /**编码器数值**/
    ros::Publisher encoder_pub = nh.advertise<std_msgs::Int64MultiArray>("/encoder_cnts", 100);
    /**电池电量输出**/
    ros::Publisher voltage_pub = nh.advertise<std_msgs::Float32>("/battery_Topic", 100);
    /**电机速度 r/min**/
    ros::Publisher speed_pub = nh.advertise<std_msgs::Int16MultiArray>("/speed_wheel", 100);
    /**电机速度 twist**/
    ros::Publisher speedTC_pub = nh.advertise<geometry_msgs::TwistWithCovariance>("/speedT_wheel", 100);
    /**电机速度没有covariance twist**/
    ros::Publisher speedT_pub = nh.advertise<geometry_msgs::Twist>("/speedT_wheel_WithoutCovariance", 100);
    /**电机的母线电流 ma**/
    ros::Publisher electic_pub = nh.advertise<std_msgs::Int16MultiArray>("/electic_topic", 100);
    /**发布imu数据**/
    ros::Publisher imu_pub = nh.advertise<sensor_msgs::Imu>("/imu_data", 100);
    /** 发布bms数据 **/
    ros::Publisher bms_pub = nh.advertise<trans_drive::Battery>("/bms_data", 100);
    /** 发布空气净化器是否打开数据 **/
    //ros::Publisher airCleaner_pub = nh.advertise<std_msgs::Int8>("/aircleaner_open", 100);
    /** 发布bms数据 **/
    //ros::Publisher bms2_pub = nh.advertise<trans_drive::Battery>("/bms_data_2", 100);
    /**订阅速度函数**/
    ros::Subscriber velocity_sub = nh.subscribe("left_right_wheel_speed", 1000, &velocityCallback);
    /**订阅下位机继电器通断话题**/
    ros::Subscriber relay_sub = nh.subscribe("relay_charge", 1, &relayCallback);
    /** 订阅操作空气净化器的函数 **/
    // ros::Subscriber aircleaner_sub = nh.subscribe("how_about_aircleaner", 1000, &aircleanerCallback);
    int64 encoderold[2] = {0, 0};
    /**主循环**/
    while (ros::ok())
    {

        //        cout<<flag<<" "<<infrared_serial.information.AirCleaner<<endl;
        // 心跳报文
        std_msgs::Int16MultiArray heartbeat_msgs;
        heartbeat_msgs.data.push_back(infrared_serial.heartbeat_message.heartbeat_timeout);
        heartbeat_msgs.data.push_back(infrared_serial.heartbeat_message.drive_error);
        heartbeat_msgs.data.push_back(infrared_serial.heartbeat_message.hit_front);
        heartbeat_msgs.data.push_back(infrared_serial.heartbeat_message.hit_back);
        heartbeat_msgs.data.push_back(infrared_serial.heartbeat_message.button_stop);
        heartbeat_msgs.data.push_back(infrared_serial.heartbeat_message.wireless_stop);
        heartbeat_msgs.data.push_back(infrared_serial.heartbeat_message.net_stop);
        heartbeat_msgs.data.push_back(infrared_serial.heartbeat_message.battery_error);
        heartbeat_msgs.data.push_back(infrared_serial.heartbeat_message.sound_error);
        heartbeat_message_pub.publish(heartbeat_msgs);
        // 读取编码器
        std_msgs::Int64MultiArray encoder_msgs;
        if (infrared_serial.encode_rx_left == true)
        {
            encoder_msgs.data.push_back(infrared_serial.information.left_encoder);
            encoderold[0] = infrared_serial.information.left_encoder;
        }
        else
        {
            encoder_msgs.data.push_back(encoderold[0]);
        }
        if (infrared_serial.encode_rx_right == true)
        {
            encoder_msgs.data.push_back(infrared_serial.information.right_encoder);
            encoderold[1] = infrared_serial.information.right_encoder;
        }
        else
        {
            encoder_msgs.data.push_back(encoderold[1]);
        }
        if ((fabs(encoder_msgs.data[0] - encoderold[0]) >= TICKS_METER) || (fabs(encoder_msgs.data[1] - encoderold[1]) >= TICKS_METER))
        {
            std::cout << "RAW_encoder_jump:" << endl;
            std::cout << "oldleft:" << encoderold[0] << endl;
            std::cout << "oldright:" << encoderold[1] << endl;
            std::cout << "left:" << encoder_msgs.data[0] << endl;
            std::cout << "right:" << encoder_msgs.data[1] << endl;
        }
        //std::cout<<"fhjlaf"<<endl;
        //cout << infrared_serial.information.left_encoder << " " << infrared_serial.information.right_encoder << endl;
        encoder_pub.publish(encoder_msgs);
        std_msgs::Float32 voltage_msgs;
        voltage_msgs.data = infrared_serial.information.voltage;
        voltage_pub.publish(voltage_msgs);
        std_msgs::Int16MultiArray speed_msgs;
        speed_msgs.data.push_back(infrared_serial.information.left_speed);
        speed_msgs.data.push_back(infrared_serial.information.right_speed);
        speed_pub.publish(speed_msgs);
        std_msgs::Int16MultiArray electric_msgs;
        electric_msgs.data.push_back(infrared_serial.information.left_electric);
        electric_msgs.data.push_back(infrared_serial.information.right_electric);
        electic_pub.publish(electric_msgs);

        geometry_msgs::TwistWithCovariance twist;
        geometry_msgs::Twist twist2;
        twist2.linear.x = twist.twist.linear.x = infrared_serial.velocity.linearX;
        twist2.linear.z = twist.twist.angular.z = infrared_serial.velocity.angularZ;
        if (infrared_serial.velocity.linearX != 0 && infrared_serial.velocity.angularZ != 0)
        {
            twist.covariance = {1e-3, 0, 0, 0, 0, 0,
                                0, 1e-3, 0, 0, 0, 0,
                                0, 0, 1e6, 0, 0, 0,
                                0, 0, 0, 1e6, 0, 0,
                                0, 0, 0, 0, 1e6, 0,
                                0, 0, 0, 0, 0, 1e3};
        }
        else
        {
            twist.covariance = {1e-9, 0, 0, 0, 0, 0,
                                0, 1e-3, 1e-9, 0, 0, 0,
                                0, 0, 1e6, 0, 0, 0,
                                0, 0, 0, 1e6, 0, 0,
                                0, 0, 0, 0, 1e6, 0,
                                0, 0, 0, 0, 0, 1e-9};
        }
        speedTC_pub.publish(twist);
        speedT_pub.publish(twist2);
        // std_msgs::Int8 msg;
        // msg.data = infrared_serial.information.AirCleaner;
        // airCleaner_pub.publish(msg);

        // 发布IMU
        sensor_msgs::Imu imu_msg;
        std_msgs::Header h;
        h.frame_id = "base_footprint";
        h.stamp = ros::Time::now();
        imu_msg.header = h;
        imu_msg.orientation_covariance = {0,0,0,0,0,0,0,0,0};//{4.11055744e-09, 0, 0, 0, 3.86600350e-09, 0, 0, 0, 3.60012753e-15};
        imu_msg.angular_velocity_covariance = {0,0,0,0,0,0,0,0,0};//{4.93157121e-07, 0, 0, 0, 6.99730792e-07, 0, 0, 0, 1.06462242e-07};
        imu_msg.linear_acceleration_covariance = {0,0,0,0,0,0,0,0,0};//{1.28480179e-04, 0, 0, 0, 1.53770710e-04, 0, 0, 0, 1.83644248e-04};
        imu_msg.angular_velocity.x = imu.imuData.angular_x;
        imu_msg.angular_velocity.y = imu.imuData.angular_y;
        imu_msg.angular_velocity.z = imu.imuData.angular_z;
        imu_msg.linear_acceleration.x = imu.imuData.acc_x;
        imu_msg.linear_acceleration.y = imu.imuData.acc_y;
        imu_msg.linear_acceleration.z = imu.imuData.acc_z;

        tf::Quaternion q = tf::createQuaternionFromRPY(imu.imuData.roll, imu.imuData.pitch, imu.imuData.yaw);
        q.normalize();
        imu_msg.orientation.x = q.x();
        imu_msg.orientation.y = q.y();
        imu_msg.orientation.z = q.z();
        imu_msg.orientation.w = q.w();
        //        cout<<imu.imuData.roll<<" "<<imu.imuData.pitch<<" "<<imu.imuData.yaw<<endl;

        imu_pub.publish(imu_msg);

        // 发布Battery信息
        trans_drive::Battery battery;
        std_msgs::Header hh;
        hh.frame_id = "battery";
        hh.stamp = ros::Time::now();
        battery.header = hh;
        battery.vcell0 = bms.bmsData.voltage_1;
        battery.vcell1 = bms.bmsData.voltage_2;
        battery.vcell2 = bms.bmsData.voltage_3;
        battery.vcell3 = bms.bmsData.voltage_4;
        battery.vcell4 = bms.bmsData.voltage_5;
        battery.vcell5 = bms.bmsData.voltage_6;
        battery.vcell6 = bms.bmsData.voltage_7;
        battery.vcell7 = bms.bmsData.voltage_8;
        battery.vcell8 = bms.bmsData.voltage_9;
        battery.vcell9 = bms.bmsData.voltage_10;
        battery.vcell10 = bms.bmsData.voltage_11;
        battery.vcell11 = bms.bmsData.voltage_12;
        battery.vcell12 = bms.bmsData.voltage_13;
        // battery.vcell13 = bms.bmsData.voltage_14;
        // battery.vcell14 = bms.bmsData.voltage_15;
        battery.temperature0 = bms.bmsData.temperature0;
        battery.temperature1 = bms.bmsData.temperature1;
        battery.temperature2 = bms.bmsData.temperature2;
        battery.voltage = bms.bmsData.totalVoltage;
        battery.curcadc = bms.bmsData.electricCurrent;
        battery.fcc = bms.bmsData.dumpEnergy;
        battery.rc = bms.bmsData.leftEnergy;
        battery.rsoc = bms.bmsData.energyPercentage;
        battery.ischarging = bms.bmsData.isCharging;
        battery.isdischarging = bms.bmsData.isDischarging;
        // if(battery.rsoc!=0)
        // {
            bms_pub.publish(battery);
        // }
        
        // 发布Battery信息
        //        trans_drive::Battery battery2;
        //        std_msgs::Header hhh;
        //        hhh.frame_id = "battery_2";
        //        hhh.stamp = ros::Time::now();
        //        battery2.header = hhh;
        //        battery2.vcell0 = bms2.bmsData.voltage_1;
        //        battery2.vcell1 = bms2.bmsData.voltage_2;
        //        battery2.vcell2 = bms2.bmsData.voltage_3;
        //        battery2.vcell3 = bms2.bmsData.voltage_4;
        //        battery2.vcell4 = bms2.bmsData.voltage_5;
        //        battery2.vcell5 = bms2.bmsData.voltage_6;
        //        battery2.vcell6 = bms2.bmsData.voltage_7;
        //        battery2.temperature0 = bms2.bmsData.temperature0;
        //        battery2.temperature1 = bms2.bmsData.temperature1;
        //        battery2.temperature2 = bms2.bmsData.temperature2;
        //        battery2.voltage = bms2.bmsData.totalVoltage;
        //        battery2.curcadc = bms2.bmsData.electricCurrent;
        //        battery2.fcc = bms2.bmsData.dumpEnergy;
        //        battery2.rc = bms2.bmsData.leftEnergy;
        //        battery2.rsoc = bms2.bmsData.energyPercentage;
        //        battery2.ischarging = bms2.bmsData.isCharging;
        //        battery2.isdischarging = bms2.bmsData.isDischarging;
        //
        //        bms2_pub.publish(battery2);

        ros::spinOnce();
        loop_rate.sleep();
    }

    infrared_serial.closeUart();
    imu.closeUart();
    bms.closeUart();
    return 0;
}
