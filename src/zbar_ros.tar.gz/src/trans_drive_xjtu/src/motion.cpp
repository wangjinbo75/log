#include "motion.h"

InfraredSerial::InfraredSerial()
{
    isOpenned = false;

    USER_TX_BUF[0] = STX;
    USER_TX_BUF[1] = ID_HEX;
    USER_TX_BUF[HANDSHAKE_SEND_LIN_START] = 0;
    USER_TX_BUF[HANDSHAKE_SEND_LIN_START + 1] = 0;
    USER_TX_BUF[SEND_NUM_SEND_LIN_START] = SEND_NUM & 0xf;
    USER_TX_BUF[SEND_NUM_SEND_LIN_START + 1] = SEND_NUM >> 4 & 0xf;
    USER_TX_BUF[DEVICE_SEND_LIN_START] = 0x0;
    USER_TX_BUF[DEVICE_SEND_LIN_START + 1] = 0x0;
    USER_TX_BUF[CMD_SEND_LINE_START] = 0x0;
    USER_TX_BUF[CMD_SEND_LINE_START + 1] = 0x0;
    USER_TX_BUF[DATA_SEND_LIN_START] = 0x0;
    USER_TX_BUF[DATA_SEND_LIN_START + 1] = 0x0;
    USER_TX_BUF[DATA_SEND_LIN_START + 2] = 0x0;
    USER_TX_BUF[DATA_SEND_LIN_START + 3] = 0x0;
    USER_TX_BUF[DATA_SEND_LIN_START + 4] = 0x0;
    USER_TX_BUF[DATA_SEND_LIN_START + 5] = 0x0;
    USER_TX_BUF[DATA_SEND_LIN_START + 6] = 0x0;
    USER_TX_BUF[DATA_SEND_LIN_START + 7] = 0x0;
    USER_TX_BUF[ETX_SEND_LIN_START] = ETX;

    USER_ASCII_BUF[0] = STX;
    USER_ASCII_BUF[SEND_NUM + 1] = ETX;

    information.left_electric = 0;
    information.left_encoder = 0;
    information.left_speed = 0;
    information.right_electric = 0;
    information.right_encoder = 0;
    information.right_speed = 0;
    information.voltage = 0;
    information.drive_sta = false;

    send_velocity.motor_left = 0;
    send_velocity.motor_right = 0;

    try
    {
        //初始化串口
        ros_serial.setPort(DIFF_DEV);
        // 设置波特率
        ros_serial.setBaudrate(DIFF_PORT);
        // 设置打开超时时间
        serial::Timeout to = serial::Timeout::simpleTimeout(1000);
        ros_serial.setTimeout(to);
        ros_serial.open();

        if (ros_serial.isOpen())
        {
            isOpenned = true;
            cout << "The trans serial has been opened!" << endl;
            // 开启线程
            int ret = start();
            if (ret == 0)
            {
                cout << "Create Motion pthread successfully!" << endl;
            }
        }
        else
        {
            ros_serial.open();
        }
    }
    catch (serial::IOException &e)
    {
        cout << "Can not open the trans serial!" << endl;
    }
}

InfraredSerial::~InfraredSerial()
{
    isOpenned = false;
}

int InfraredSerial::start()
{
    if (pthread_create(&pid, NULL, start_thread, (void *)this) != 0) //´创建一个线程(必须是全局函数)
    {
        return -1;
    }
    return 0;
}

void *InfraredSerial::start_thread(void *arg)
{
    InfraredSerial *ptr = (InfraredSerial *)arg;
    //    ptr->uart_explain();
    ptr->uart_main();
}

void InfraredSerial::uart_main()
{

    int sStep = 0;
    const int sStep_end = 255;

    int explain_step = 0;
    int first_encode[2] = {0, 0};
    int encode[2] = {0, 0};
    while (isOpenned)
    {
        switch (sStep)
        {
        case 0:
            //printf("send speed:\n");
            uart_send_speed(send_velocity.motor_left, send_velocity.motor_right);
            explain_step = sStep;
            sStep = sStep_end;
            break;
        case 1:
            // printf("%d \n",num);
            uart_get_encode_left();
            explain_step = sStep;
            sStep = sStep_end;
            break;
        case 2:
            uart_get_encode_right();
            explain_step = sStep;
            sStep = sStep_end;
            break;
        case 3:
            uart_get_speed();
            explain_step = sStep;
            sStep = sStep_end;
            break;
        case 4:
            uart_get_heartbeat_message();
            explain_step = sStep;
            sStep = sStep_end;
            break;
        case 5:
            uart_set_relay();
            explain_step = sStep;
            sStep = sStep_end;
            break;
        case 6:
            sStep = 0;
            break;

        case sStep_end:
            CRC_CHECK();
            H2A();
            //printSerialSend();
            std::string str = (char *)USER_ASCII_BUF;
            ros_serial.write(str);
            uart_explain();
            if (data_update)
            {
                switch (explain_step)
                {
                case 0:
                    if ((gDevice == KINCO_DRIVER) & (gCMD == ACK))
                    {
                        speed_tx = true;
                    }
                    else
                    {
                        speed_tx = false;
                    }
                    sStep = explain_step + 1;
                    // sStep = 1;
                    break;
                case 1:
                    if ((gDevice == KINCO_DRIVER) & (gCMD == ACK))
                    {
                        encode[0] =
                            (gData[7] << 28) | (gData[6] << 24) | (gData[5] << 20) | (gData[4] << 16) | (gData[3] << 12) | (gData[2] << 8) | (gData[1] << 4) | gData[0];
                        if (left_to_right)
                        {
                            encode_rx_right = true;
                        }
                        else
                        {
                            encode_rx_left = true;
                        }
                        if ((first_encode[0] == 0))
                        {
                            first_encode[0] = encode[0];
                        }
                        if (left_to_right)
                        {
                            information.right_encoder = encode[0] - first_encode[0];
                        }
                        else
                        {
                            information.left_encoder = encode[0] - first_encode[0];
                        }
                    }
                    else
                    {
                        if (left_to_right)
                        {
                            encode_rx_right = false;
                        }
                        else
                        {
                            encode_rx_left = false;
                        }
                    }
                    sStep = explain_step + 1;
                    // sStep =1;
                    break;
                case 2:
                    if ((gDevice == KINCO_DRIVER) & (gCMD == ACK))
                    {
                        encode[1] =
                            (gData[7] << 28) | (gData[6] << 24) | (gData[5] << 20) | (gData[4] << 16) | (gData[3] << 12) | (gData[2] << 8) | (gData[1] << 4) | gData[0];
                        if (left_to_right)
                        {
                            encode_rx_left = true;
                        }
                        else
                        {
                            encode_rx_right = true;
                        }

                        if ((first_encode[1] == 0))
                        {
                            first_encode[1] = encode[1];
                        }
                        if (left_to_right)
                        {
                            information.left_encoder = encode[1] - first_encode[1];
                        }
                        else
                        {
                            information.right_encoder = encode[1] - first_encode[1];
                        }
                    }
                    else
                    {
                        if (left_to_right)
                        {
                            encode_rx_left = false;
                        }
                        else
                        {
                            encode_rx_right = false;
                        }
                    }
                    sStep = explain_step + 1;
                    // sStep = 0;
                    break;
                case 3:
                    if ((gDevice == KINCO_DRIVER) & (gCMD == ACK))
                    {
                        information.left_speed = (gData[3] << 12) | (gData[2] << 8) | (gData[1] << 4) | gData[0];
                        information.right_speed = (gData[7] << 12) | (gData[6] << 8) | (gData[5] << 4) | gData[4];
                        // if (left_to_right)
                        // {
                        //     int16 temp = -information.left_speed;
                        //     information.left_speed = -information.right_speed;
                        //     information.right_speed = temp;
                        // }
                        velocity = motorTotwist(information.left_speed, information.right_speed);

                        speed_rx = true;
                    }
                    else
                    {
                        speed_rx = false;
                    }
                    sStep = explain_step + 1;
                    // sStep = 0;
                    break;
                case 4:
                    if ((gDevice == HEARTBEAT_MESSAGE) & (gCMD == ACK))
                    {
                        unsigned int sys_sta =
                            (gData[7] << 28) | (gData[6] << 24) | (gData[5] << 20) | (gData[4] << 16) | (gData[3] << 12) | (gData[2] << 8) | (gData[1] << 4) | gData[0];

                        heartbeat_message.heartbeat_timeout = ((sys_sta & 0x1) == 0x0) ? 0 : 1;
                        heartbeat_message.drive_error = (((sys_sta >> 1) & 0x1) == 0x0) ? 0 : 1;
                        heartbeat_message.hit_front = (((sys_sta >> 2) & 0x1) == 0x0) ? 0 : 1;
                        heartbeat_message.hit_back = (((sys_sta >> 3) & 0x1) == 0x0) ? 0 : 1;
                        heartbeat_message.button_stop = (((sys_sta >> 4) & 0x1) == 0x0) ? 0 : 1;
                        heartbeat_message.wireless_stop = (((sys_sta >> 5) & 0x1) == 0x0) ? 0 : 1;
                        heartbeat_message.net_stop = (((sys_sta >> 6) & 0x1) == 0x0) ? 0 : 1;
                        heartbeat_message.battery_error = (((sys_sta >> 7) & 0x1) == 0x0) ? 0 : 1;
                        heartbeat_message.sound_error = (((sys_sta >> 8) & 0x1) == 0x0) ? 0 : 1;
                    }
                    sStep = explain_step + 1;
                    break;
                case 5:
                    if ((gDevice == KINCO_DRIVER) & (gCMD == ACK))
                    {
                        unsigned int data =
                            (gData[7] << 28) | (gData[6] << 24) | (gData[5] << 20) | (gData[4] << 16) | (gData[3] << 12) | (gData[2] << 8) | (gData[1] << 4) | gData[0];
                        if (data == 0)
                        {
                            information.drive_sta = true;
                        }
                        else
                        {
                            information.drive_sta = false;
                        }
                    }
                    sStep = explain_step + 1;
                    // sStep = 0;
                    break;
                case 6:
                    sStep = explain_step + 1;
                    break;
                }
            }
        }
        usleep(4);
    }
}

void InfraredSerial::printSerialSend()
{
    for (int i = 0; i <= SEND_NUM + 1; i++)
    {
        printf("send data:%d %#x \n", i, USER_ASCII_BUF[i]);
    }
    printf("\r\n");
}

void InfraredSerial::uart_get_encode_left()
{
    unsigned char Device = KINCO_DRIVER;
    USER_TX_BUF[DEVICE_SEND_LIN_START] = Device & 0xf;
    USER_TX_BUF[DEVICE_SEND_LIN_START + 1] = Device >> 4 & 0xf;

    unsigned char CMD = CHECK_ABS_POSA;
    USER_TX_BUF[CMD_SEND_LINE_START] = CMD & 0xf;
    USER_TX_BUF[CMD_SEND_LINE_START + 1] = CMD >> 4 & 0xf;
}

void InfraredSerial::uart_get_encode_right()
{
    unsigned char Device = KINCO_DRIVER;
    USER_TX_BUF[DEVICE_SEND_LIN_START] = Device & 0xf;
    USER_TX_BUF[DEVICE_SEND_LIN_START + 1] = Device >> 4 & 0xf;

    unsigned char CMD = CHECK_ABS_POSB;
    USER_TX_BUF[CMD_SEND_LINE_START] = CMD & 0xf;
    USER_TX_BUF[CMD_SEND_LINE_START + 1] = CMD >> 4 & 0xf;
}

void InfraredSerial::uart_get_speed()
{
    unsigned char Device = KINCO_DRIVER;
    USER_TX_BUF[DEVICE_SEND_LIN_START] = Device & 0xf;
    USER_TX_BUF[DEVICE_SEND_LIN_START + 1] = Device >> 4 & 0xf;

    unsigned char CMD = CHECK_CUR_SPEED;
    USER_TX_BUF[CMD_SEND_LINE_START] = CMD & 0xf;
    USER_TX_BUF[CMD_SEND_LINE_START + 1] = CMD >> 4 & 0xf;
}

void InfraredSerial::uart_get_kinco_state()
{
    unsigned char Device = KINCO_DRIVER;
    USER_TX_BUF[DEVICE_SEND_LIN_START] = Device & 0xf;
    USER_TX_BUF[DEVICE_SEND_LIN_START + 1] = Device >> 4 & 0xf;

    unsigned char CMD = CHECK_ENQ;
    USER_TX_BUF[CMD_SEND_LINE_START] = CMD & 0xf;
    USER_TX_BUF[CMD_SEND_LINE_START + 1] = CMD >> 4 & 0xf;
}

void InfraredSerial::uart_get_heartbeat_message()
{
    unsigned char Device = HEARTBEAT_MESSAGE;
    USER_TX_BUF[DEVICE_SEND_LIN_START] = Device & 0xf;
    USER_TX_BUF[DEVICE_SEND_LIN_START + 1] = Device >> 4 & 0xf;

    unsigned char CMD = CHECK_ENQ;
    USER_TX_BUF[CMD_SEND_LINE_START] = CMD & 0xf;
    USER_TX_BUF[CMD_SEND_LINE_START + 1] = CMD >> 4 & 0xf;

    USER_TX_BUF[DATA_SEND_LIN_START] = 0x0;
    USER_TX_BUF[DATA_SEND_LIN_START + 1] = 0x0;
    USER_TX_BUF[DATA_SEND_LIN_START + 2] = 0x0;
    USER_TX_BUF[DATA_SEND_LIN_START + 3] = 0x0;
    USER_TX_BUF[DATA_SEND_LIN_START + 4] = 0x0;
    USER_TX_BUF[DATA_SEND_LIN_START + 5] = 0x0;
    USER_TX_BUF[DATA_SEND_LIN_START + 6] = 0x0;
    USER_TX_BUF[DATA_SEND_LIN_START + 7] = 0x0;
}

void InfraredSerial::uart_send_speed(short left, short right)
{
    unsigned char Device = KINCO_DRIVER;
    USER_TX_BUF[DEVICE_SEND_LIN_START] = Device & 0xf;
    USER_TX_BUF[DEVICE_SEND_LIN_START + 1] = Device >> 4 & 0xf;

    unsigned char CMD = SET_TARG_SPEED;
    USER_TX_BUF[CMD_SEND_LINE_START] = CMD & 0xf;
    USER_TX_BUF[CMD_SEND_LINE_START + 1] = CMD >> 4 & 0xf;

    if (left_to_right)
    {
        short temp = left;
        left = right;
        right = temp;
    }

    USER_TX_BUF[DATA_SEND_LIN_START] = left & 0x0f;
    USER_TX_BUF[DATA_SEND_LIN_START + 1] = left >> 4 & 0x0f;
    USER_TX_BUF[DATA_SEND_LIN_START + 2] = left >> 8 & 0x0f;
    USER_TX_BUF[DATA_SEND_LIN_START + 3] = left >> 12 & 0x0f;
    USER_TX_BUF[DATA_SEND_LIN_START + 4] = right & 0x0f;
    USER_TX_BUF[DATA_SEND_LIN_START + 5] = right >> 4 & 0x0f;
    USER_TX_BUF[DATA_SEND_LIN_START + 6] = right >> 8 & 0x0f;
    USER_TX_BUF[DATA_SEND_LIN_START + 7] = right >> 12 & 0x0f;
    // for (int i = 0; i <= SEND_NUM + 1; i++)
    // {
    //     printf("send data:%d %#x \n", i, USER_ASCII_BUF[i]);
    // }
}

void InfraredSerial::uart_set_relay()
{
    unsigned char Device = RELAY;
    USER_TX_BUF[DEVICE_SEND_LIN_START] = Device & 0xf;
    USER_TX_BUF[DEVICE_SEND_LIN_START + 1] = Device >> 4 & 0xf;

    unsigned char CMD = SET_RELAY;
    USER_TX_BUF[CMD_SEND_LINE_START] = CMD & 0xf;
    USER_TX_BUF[CMD_SEND_LINE_START + 1] = CMD >> 4 & 0xf;

    int relay = 1;
    USER_TX_BUF[DATA_SEND_LIN_START] = relay & 0x0f;
    USER_TX_BUF[DATA_SEND_LIN_START + 1] = relay >> 4 & 0x0f;
    USER_TX_BUF[DATA_SEND_LIN_START + 2] = relay >> 8 & 0x0f;
    USER_TX_BUF[DATA_SEND_LIN_START + 3] = relay >> 12 & 0x0f;

    USER_TX_BUF[DATA_SEND_LIN_START + 4] = relay_flag & 0x0f;
    USER_TX_BUF[DATA_SEND_LIN_START + 5] = relay_flag >> 4 & 0x0f;
    USER_TX_BUF[DATA_SEND_LIN_START + 6] = relay_flag >> 8 & 0x0f;
    USER_TX_BUF[DATA_SEND_LIN_START + 7] = relay_flag >> 12 & 0x0f;
    // for (int i = 0; i <= SEND_NUM + 1; i++)
    // {
    //     printf("send data:%d %#x \n", i, USER_ASCII_BUF[i]);
    // }
}

void InfraredSerial::uart_explain()
{
    //    if (ros_serial.available()) {

    std::string str = ros_serial.read(23); //(*ser).available() //23
    // printf( "receive: %s \n", str.c_str() );
    USER_RX_ASCII_BUF = (unsigned char *)(str.c_str());
    if (USER_RX_ASCII_BUF[0] == STX & USER_RX_ASCII_BUF[ETX_RECE_LIN_START] == ETX)
    {

        data_update = true;
        //            num ++;
        //            printf("num:%d \n", num);
        // printf("receive data:%d %#x \n", 0, USER_RX_ASCII_BUF[0]);
        for (int i = 1; i <= RECE_NUM; i++)
        {
            USER_RX_BUF[i] = ASCIItoHEX(USER_RX_ASCII_BUF[i]);
            // printf("receive data:%d %#x \n", i, USER_RX_BUF[i]);
        }
        // printf("receive data:%d %#x \n", 22, USER_RX_ASCII_BUF[22]);

        unsigned short crc_result = 0xFFFF;
        for (int i = 1; i < CRC_RECE_LIN_START; i++)
        {
            crc_result = CRC16_CHECK(USER_RX_BUF[i], crc_result);
        }

        // printf("receive data:%d %#x \n", CRC_RECE_LIN_START, crc_result & 0xf);
        // printf("receive data:%d %#x \n", CRC_RECE_LIN_START + 1, crc_result >> 4 & 0xf);
        // printf("receive data:%d %#x \n", CRC_RECE_LIN_START + 2, crc_result >> 8 & 0xf);
        // printf("receive data:%d %#x \n", CRC_RECE_LIN_START + 3, crc_result >> 12 & 0xf);

        if ((USER_RX_BUF[CRC_RECE_LIN_START] == (crc_result & 0x0f)) & (USER_RX_BUF[CRC_RECE_LIN_START + 1] == (crc_result >> 4 & 0x0f)) & (USER_RX_BUF[CRC_RECE_LIN_START + 2] == (crc_result >> 8 & 0x0f)) & (USER_RX_BUF[CRC_RECE_LIN_START + 3] == (crc_result >> 12 & 0x0f)))
        {

            gHandShake = USER_RX_BUF[HANDSHAKE_RECE_LIN_START + 1] << 4 | USER_RX_BUF[HANDSHAKE_RECE_LIN_START];
            gNum = USER_RX_BUF[NUM_RECE_LIN_START + 1] << 4 | USER_RX_BUF[NUM_RECE_LIN_START];
            gDevice = USER_RX_BUF[DEVICE_RECE_LIN_START + 1] << 4 | USER_RX_BUF[DEVICE_RECE_LIN_START];
            gCMD = USER_RX_BUF[CMD_SEND_LINE_START + 1] << 4 | USER_RX_BUF[CMD_RECE_LINE_START];
            gData[0] = USER_RX_BUF[DATA_RECE_LIN_START];
            gData[1] = USER_RX_BUF[DATA_RECE_LIN_START + 1];
            gData[2] = USER_RX_BUF[DATA_RECE_LIN_START + 2];
            gData[3] = USER_RX_BUF[DATA_RECE_LIN_START + 3];
            gData[4] = USER_RX_BUF[DATA_RECE_LIN_START + 4];
            gData[5] = USER_RX_BUF[DATA_RECE_LIN_START + 5];
            gData[6] = USER_RX_BUF[DATA_RECE_LIN_START + 6];
            gData[7] = USER_RX_BUF[DATA_RECE_LIN_START + 7];
            // printf("%#x \n", gDevice);
            // printf("%#x \n", gCMD);
        }
        else
        {
            gDevice = 0x00;
            gCMD = 0x00;
        }
    }
    else
    {
        data_update = false;
    }
    //    }
}

youi_robot_namespace::RobotVelocityData InfraredSerial::motorTotwist(int16 left, int16 right)
{
    youi_robot_namespace::RobotVelocityData data;
    data.linearX = (((left + right) / 2.0) / 60.0) * PI * (DIAMETER / 1000.0) / REDUCTION;
    data.angularZ = (((right - left) / BASE_WIDTH) / 60.0) * PI * (DIAMETER / 1000.0) / REDUCTION;

    return data;
}

void InfraredSerial::closeUart()
{
    // if (isOpenned)
    // {
    // sleep(1);
    // isOpenned = false;
    // 重置下位机软件
    // ros_serial.write(tx_reset,4);
    // cout << "Stm32 has been reseted!"<< endl;
    //        sleep(3);
    //        ros_serial.write(tx_reset,4);
    //        cout<<"Stm32 has been reseted!"<<"2"<<endl;
    // }
    sleep(1);
    isOpenned = false;
    ros_serial.close();
    if (!ros_serial.isOpen())
    {
        cout << "Stm32 serial closed!" << endl;
    }
}

unsigned char InfraredSerial::ASCIItoHEX(unsigned char RxData)
{
    if (RxData >= '0' && RxData <= '9')
    {
        RxData -= '0';
    }
    else if (RxData >= 'a' && RxData <= 'f')
    {
        RxData -= ('a' - 10);
    }
    else if (RxData >= 'A' && RxData <= 'F')
    {
        RxData -= ('A' - 10);
    }
    else
        return 0;
    return RxData;
}

// HEXTOASCII TOTAL
void InfraredSerial::H2A()
{
    for (int i = 1; i <= SEND_NUM; i++)
    {
        USER_ASCII_BUF[i] = HEXtoASCII(USER_TX_BUF[i]);
    }
}

/**16进制转成ASCII**/
unsigned char InfraredSerial::HEXtoASCII(unsigned char TxData)
{
    TxData &= 0xf;
    if (TxData > 9)
        TxData += ('A' - 10);
    else
        TxData += '0';
    return TxData;
}

void InfraredSerial::CRC_CHECK()
{
    unsigned short crc_result = 0xFFFF;
    for (int i = 1; i < CRC_SEND_LIN_START; i++)
    {
        crc_result = CRC16_CHECK(USER_TX_BUF[i], crc_result);
    }
    USER_TX_BUF[CRC_SEND_LIN_START] = crc_result & 0xf;
    USER_TX_BUF[CRC_SEND_LIN_START + 1] = crc_result >> 4 & 0xf;
    USER_TX_BUF[CRC_SEND_LIN_START + 2] = crc_result >> 8 & 0xf;
    USER_TX_BUF[CRC_SEND_LIN_START + 3] = crc_result >> 12 & 0xf;
}

/**CRC校验程序单字节**/
unsigned short InfraredSerial::CRC16_CHECK(unsigned char Data, unsigned short CRC_Init)
{
    static unsigned short CRC_REG;
    static unsigned char move_num;

    CRC_REG = (CRC_Init & 0xFF00) | (Data ^ (CRC_Init & 0x00FF));

    for (move_num = 1; move_num < 9; move_num++)
    {
        if (CRC_REG & 0x0001)
        {
            CRC_REG = (CRC_REG >> 1) ^ 0xA001;
        }
        else
        {
            CRC_REG = CRC_REG >> 1;
        }
    }
    return CRC_REG;
}
