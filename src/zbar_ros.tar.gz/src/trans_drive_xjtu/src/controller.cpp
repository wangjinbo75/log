#include "controller.h"

Controller::Controller()
{
    base_width = BASE_WIDTH;
    ticks_meter = TICKS_METER;
    duration = 50;
    enc_left = 0;
    enc_right = 0;
    mot.motor_left = 0;
    mot.motor_left = 0;
    encoder_.left_encoder = 0;
    encoder_.right_encoder = 0;
    pose_.x = 0;
    pose_.y = 0;
    pose_.theta = 0;
    pose_.linear_x = 0;
    pose_.angular_z = 0;
    pose_.qua_w = 0;
    pose_.qua_x = 0;
    pose_.qua_y = 0;
    pose_.qua_z = 0;
    theta = 0;

    publish_odom = true;
    int ret = start();
    if (ret == 0)
    {
        cout << "Create pthread successfully!" << endl;
    }

    now = getTime();
    then = now;
    t_next = now + duration;
}

Controller::~Controller()
{
    publish_odom = false;
    cout << "Release the Controller target!" << endl;
}

void *Controller::start_thread(void *arg)
{
    Controller *ptr = (Controller *)arg;
    ptr->produce_odom();
}

int Controller::start()
{
    if (pthread_create(&pid, NULL, start_thread, (void *)this) != 0) //´创建一个线程(必须是全局函数)
    {
        return -1;
    }
    return 0;
}

void Controller::twist2motor(float32 linear_x, float32 angular_z)
{
    float dx = linear_x;
    float dr = angular_z;

    float right = 1.0 * dx + dr * base_width / 2.0;
    float left = 1.0 * dx - dr * base_width / 2.0;

    mot.motor_left = floor(left * 100);
    mot.motor_right = floor(right * 100);

    // cout<<getTime()<<" motor: "<<mot.motor_left<<" "<<mot.motor_right<<endl;
}

time_t Controller::getTime()
{
    chrono::time_point<chrono::system_clock, chrono::milliseconds> tp = chrono::time_point_cast<chrono::milliseconds>(chrono::system_clock::now());
    auto tmp = chrono::duration_cast<chrono::milliseconds>(tp.time_since_epoch());
    time_t timestamp = tmp.count();
    //const boost::posix_time::ptime now = boost::posix_time::microsec_clock::local_time();
    //const boost::posix_time::time_duration td = now.time_of_day();
    //const long milliseconds = td.total_microseconds();
    //const long milliseconds = 0;
    return timestamp;
}

void Controller::produce_odom()
{
    /**左右两个轮子分别走过的路程**/
    float d_left;
    float d_right;
    /**里程计数据**/
    float d = 0;
    float th = 0;
    float th_add = 0;
    float x = 0;
    float y = 0;
    /**速度**/
    float dx = 0;
    float dz = 0;
    /**左右两个轮子的编码器读数**/
    long left = 0;
    long right = 0;

    long oldleft = 0;
    long oldright = 0;
    while (publish_odom)
    {
        oldleft = left;
        oldright = right;
        left = encoder_.left_encoder;
        right = encoder_.right_encoder;
        if (fabs(left - oldleft) >= TICKS_METER || fabs(right - oldright) >= TICKS_METER)
        {            
            std::cout<<"encoder_jump:"<<endl;
            std::cout<<"oldleft:"<<oldleft<<endl;
            std::cout<<"oldright:"<<oldright<<endl;
            std::cout<<"left:"<<left<<endl;
            std::cout<<"right:"<<right<<endl;
            continue;
        }

        /**系统时间精确到ms**/
        now = getTime();
        //cout<<"now   : "<<now<<endl;
        //cout<<"t_next: "<<t_next<<endl;
        if (now > t_next)
        {
            elapsed = now - then;
            then = now;
            if (enc_left == 0 && enc_right == 0)
            {
                d_left = 0;
                d_right = 0;
            }
            else
            {
                d_left = (left - enc_left) / ticks_meter;
                d_right = (right - enc_right) / ticks_meter;
            }
            enc_left = left;
            enc_right = right;
            /**左右两个轮子走过的平均距离**/
            d = (d_left + d_right) / 2.0;
            /**转过的角度**/
            //            if(ODOM_USE_IMU > 0)
            //            {
            //                th = theta;
            //            }else{
            //                th = (d_right - d_left) / base_width;
            //            }
            th = (d_right - d_left) / base_width;
            dx = d / (elapsed / 1000.0);
            dz = th / (elapsed / 1000.0);
            //            cout<<elapsed<<endl;
            if (d != 0)
            {
                float xx = cos(th) * d;
                float yy = -sin(th) * d;
                x = x + (cos(th_add) * xx - sin(th_add) * yy);
                y = y + (sin(th_add) * xx + cos(th_add) * yy);
            }
            if (th != 0)
            {
                th_add = th_add + th;

                if (th_add > PI)
                {
                    th_add = th_add - 2 * PI;
                }
                if (th_add < -PI)
                {
                    th_add = th_add + 2 * PI;
                }
            }

            pose_.linear_x = dx;
            pose_.angular_z = dz;
            pose_.x = x;
            pose_.y = y;
            pose_.theta = th_add;
            pose_.qua_z = sin(th_add / 2.0);
            pose_.qua_w = cos(th_add / 2.0);
            // cout<<pose_.x<<" "<<pose_.y<<" "<<pose_.theta<<endl;
        }
        /**睡duration ms**/
        sleep(duration / 1000.0);
    }
}

void Controller::Delay(int mseconds)
{
    int64_t start = getTime();
    while ((getTime() - start) < mseconds)
    {
        continue;
    }
}

void Controller::close_thread()
{
    publish_odom = false;
    //cout<<publish_odom<<endl;
}
