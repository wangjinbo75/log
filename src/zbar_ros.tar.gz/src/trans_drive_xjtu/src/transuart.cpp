#include "transuart.h"
#include <string>

bool transuart::SPEED_USART_TX_INTERFACE(short targ_speed_A, short targ_speed_B)
{
    unsigned char Device = 0x11;
    USER_TX_BUF[DEVICE_SEND_LIN_START] = Device & 0xf;
    USER_TX_BUF[DEVICE_SEND_LIN_START + 1] = Device >> 4 & 0xf;

    unsigned char CMD = 0x04;
    USER_TX_BUF[CMD_SEND_LINE_START] = CMD & 0xf;
    USER_TX_BUF[CMD_SEND_LINE_START + 1] = CMD >> 4 & 0xf;

    USER_TX_BUF[DATA_SEND_LIN_START] = targ_speed_A & 0x0f;
    USER_TX_BUF[DATA_SEND_LIN_START + 1] = targ_speed_A >> 4 & 0x0f;
    USER_TX_BUF[DATA_SEND_LIN_START + 2] = targ_speed_A >> 8 & 0x0f;
    USER_TX_BUF[DATA_SEND_LIN_START + 3] = targ_speed_A >> 12 & 0x0f;
    USER_TX_BUF[DATA_SEND_LIN_START + 4] = targ_speed_B & 0x0f;
    USER_TX_BUF[DATA_SEND_LIN_START + 5] = targ_speed_B >> 4 & 0x0f;
    USER_TX_BUF[DATA_SEND_LIN_START + 6] = targ_speed_B >> 8 & 0x0f;
    USER_TX_BUF[DATA_SEND_LIN_START + 7] = targ_speed_B >> 12 & 0x0f;

    CRC_CHECK();
    H2A();
    // for (int i = 0; i <= SEND_NUM; i++)
    // {
    //     printf("send data:%d %#x \n", i, USER_TX_BUF[i]);
    // }
    for (int i = 0; i <= SEND_NUM + 1; i++)
    {
        printf("send data:%d %#x \n", i, USER_ASCII_BUF[i]);
    }
    std::string str = (char *)USER_ASCII_BUF;
    (*ser).write(str);
    UART_RX_INTERFACE();
    if ((gDevice == 0x11) & (gCMD == ACK))
    {
        return true;
    }
    else
    {
        return false;
    }
}

void transuart::GETENCODE_USART_TX_INTERFACE(int *encode)
{
    int left_encode =0;
    int right_encode =0;
    unsigned char Device = 0x11;
    USER_TX_BUF[DEVICE_SEND_LIN_START] = Device & 0xf;
    USER_TX_BUF[DEVICE_SEND_LIN_START + 1] = Device >> 4 & 0xf;

    unsigned char CMD = 0x01;
    USER_TX_BUF[CMD_SEND_LINE_START] = CMD & 0xf;
    USER_TX_BUF[CMD_SEND_LINE_START + 1] = CMD >> 4 & 0xf;
    CRC_CHECK();
    H2A();
    std::string str = (char *)USER_ASCII_BUF;
    (*ser).write(str);
    UART_RX_INTERFACE();

    if ((gDevice == 0x11) & (gCMD == ACK))
    {

        left_encode= encode[0] = (gData[7] << 28) |
                    (gData[6] << 24) |
                    (gData[5] << 20) |
                    (gData[4] << 16) |
                    (gData[3] << 12) |
                    (gData[2] << 8) |
                    (gData[1] << 4) |
                    gData[0];
    }
    else
    {
        encode[0] = 0;
    }

    CMD = 0x02;
    USER_TX_BUF[CMD_SEND_LINE_START] = CMD & 0xf;
    USER_TX_BUF[CMD_SEND_LINE_START + 1] = CMD >> 4 & 0xf;
    CRC_CHECK();
    H2A();
    str = (char *)USER_ASCII_BUF;
    (*ser).write(str);
    UART_RX_INTERFACE();
    if ((gDevice == 0x11) & (gCMD == ACK))
    {

        right_encode= encode[1] = (gData[7] << 28) |
                    (gData[6] << 24) |
                    (gData[5] << 20) |
                    (gData[4] << 16) |
                    (gData[3] << 12) |
                    (gData[2] << 8) |
                    (gData[1] << 4) |
                    gData[0];
    }
    else
    {
        encode[1] = 0;
    }

}

void transuart::UART_RX_INTERFACE()
{
    std::string str = (*ser).read(23); //(*ser).available() //23
    printf("receive: %s \n", str.c_str());
    USER_RX_ASCII_BUF = (unsigned char *)(str.c_str());
    unsigned short crc_result = 0xFFFF;
    for (int i = 1; i <= RECE_NUM; i++)
    {
        USER_RX_BUF[i] = ASCIItoHEX(USER_RX_ASCII_BUF[i]);
        //printf("receive data:%d %#x \n", i, USER_RX_BUF[i]);
    }
    for (int i = 1; i < CRC_RECE_LIN_START; i++)
    {
        crc_result = CRC16_CHECK(USER_RX_BUF[i], crc_result);
    }

    printf("receive data:%d %#x \n", CRC_RECE_LIN_START, crc_result & 0xf);
    printf("receive data:%d %#x \n", CRC_RECE_LIN_START + 1, crc_result >> 4 & 0xf);
    printf("receive data:%d %#x \n", CRC_RECE_LIN_START + 2, crc_result >> 8 & 0xf);
    printf("receive data:%d %#x \n", CRC_RECE_LIN_START + 3, crc_result >> 12 & 0xf);
    // gCMD = USER_RX_BUF[CMD_SEND_LINE_START + 1] << 4 | USER_RX_BUF[CMD_SEND_LINE_START];
    // printf("%#x", gCMD);

    if ((USER_RX_BUF[CRC_RECE_LIN_START] == (crc_result & 0x0f)) &
        (USER_RX_BUF[CRC_RECE_LIN_START + 1] == (crc_result >> 4 & 0x0f)) &
        (USER_RX_BUF[CRC_RECE_LIN_START + 2] == (crc_result >> 8 & 0x0f)) &
        (USER_RX_BUF[CRC_RECE_LIN_START + 3] == (crc_result >> 12 & 0x0f)) &
        (USER_RX_ASCII_BUF[0] == 0x02) &
        (USER_RX_ASCII_BUF[RECE_NUM + 1] == 0x03))
    {
        gHandShake = USER_RX_BUF[HANDSHAKE_RECE_LIN_START + 1] << 4 | USER_RX_BUF[HANDSHAKE_RECE_LIN_START];
        gNum = USER_RX_BUF[NUM_RECE_LIN_START + 1] << 4 | USER_RX_BUF[NUM_RECE_LIN_START];
        gDevice = USER_RX_BUF[DEVICE_RECE_LIN_START + 1] << 4 | USER_RX_BUF[DEVICE_RECE_LIN_START];
        gCMD = USER_RX_BUF[CMD_SEND_LINE_START + 1] << 4 | USER_RX_BUF[CMD_RECE_LINE_START];
        gData[0] = USER_RX_BUF[DATA_RECE_LIN_START];
        gData[1] = USER_RX_BUF[DATA_RECE_LIN_START + 1];
        gData[2] = USER_RX_BUF[DATA_RECE_LIN_START + 2];
        gData[3] = USER_RX_BUF[DATA_RECE_LIN_START + 3];
        gData[4] = USER_RX_BUF[DATA_RECE_LIN_START + 4];
        gData[5] = USER_RX_BUF[DATA_RECE_LIN_START + 5];
        gData[6] = USER_RX_BUF[DATA_RECE_LIN_START + 6];
        gData[7] = USER_RX_BUF[DATA_RECE_LIN_START + 7];
        // gData = USER_RX_BUF[DATA_RECE_LIN_START + 7] << 28 |
        //         USER_RX_BUF[DATA_RECE_LIN_START + 6] << 24 |
        //         USER_RX_BUF[DATA_RECE_LIN_START + 5] << 20 |
        //         USER_RX_BUF[DATA_RECE_LIN_START + 4] << 16 |
        //         USER_RX_BUF[DATA_RECE_LIN_START + 3] << 12 |
        //         USER_RX_BUF[DATA_RECE_LIN_START + 2] << 8 |
        //         USER_RX_BUF[DATA_RECE_LIN_START + 1] << 4 |
        //         USER_RX_BUF[DATA_RECE_LIN_START];
        printf("%#x \n", gDevice);
        printf("%#x \n", gCMD);
        //printf("%#x \n", gData);
    }
}