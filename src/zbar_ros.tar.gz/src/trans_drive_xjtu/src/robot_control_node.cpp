
/*
 * Bug: filter time older than odom message buffer
*/

#include <ros/ros.h>
#include <std_msgs/Int16MultiArray.h>
#include <std_msgs/Int32MultiArray.h>
#include <std_msgs/Int64MultiArray.h>
#include <std_msgs/Float32.h>
#include <geometry_msgs/Twist.h>
#include <nav_msgs/Odometry.h>
#include <sensor_msgs/Imu.h>
#include <controller.h>
#include <tf/transform_broadcaster.h>

using namespace std;

Controller controller;
/**判断是否收到速度命令**/
int receive_cmd = 0;
int64 oldencoder[2] = {0, 0};
float x, y, z, w;

nav_msgs::Odometry odom;

void Callback(const geometry_msgs::Twist::ConstPtr &msg)
{
    receive_cmd = 0;
    controller.twist2motor(msg->linear.x, msg->angular.z);
    //    ROS_INFO("writing %d %d",left_velocity,right_velocity);
}

void encoderCallback(const std_msgs::Int64MultiArray::ConstPtr &msg)
{
    //    controller.publish_odom = true;
    oldencoder[0] = controller.encoder_.left_encoder;
    oldencoder[1] = controller.encoder_.right_encoder;
    if (fabs(msg->data[0] - oldencoder[0]) >= TICKS_METER)
    {
        controller.encoder_.left_encoder = oldencoder[0];
        cout << "Topic_encoder_jump:" << endl;
        cout << "old_left:" << oldencoder[0] << endl;
        cout << "left_encoder:" << msg->data[0] << endl;
    }
    else
    {
        controller.encoder_.left_encoder = msg->data[0];
    }
    if (fabs(msg->data[1] - oldencoder[1]) >= TICKS_METER)
    {
        controller.encoder_.right_encoder = oldencoder[1];
        cout << "Topic_encoder_jump:" << endl;
        cout << "old_right:" << oldencoder[1] << endl;
        cout << "right_encoder:" << msg->data[1] << endl;
    }
    else
    {
        controller.encoder_.right_encoder = msg->data[1];
    }
}

void imuCallback(const sensor_msgs::Imu::ConstPtr &msg)
{
    x = msg->orientation.x;
    y = msg->orientation.y;
    z = msg->orientation.z;
    w = msg->orientation.w;

    controller.theta = atan2(2 * (x * y + w * z), w * w + x * x - y * y - z * z);
    //cout<< controller.theta <<endl;
    //    cout<<ODOM_USE_IMU<<endl;
}

void speedCallback(const geometry_msgs::TwistWithCovarianceConstPtr &msg)
{
    odom.twist.twist.linear.x = msg->twist.linear.x;
    odom.twist.twist.angular.z = msg->twist.angular.z;
    odom.twist.covariance = msg->covariance;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "controller_base");
    ros::NodeHandle nh;
    ros::Rate loop_rate(30);
    /**发布速度命令**/
    ros::Publisher velocity_pub = nh.advertise<std_msgs::Int16MultiArray>("/left_right_wheel_speed", 100);
    /**发布里程计命令**/
    ros::Publisher odom_pub = nh.advertise<nav_msgs::Odometry>("odom", 1000);
    /**订阅速度函数**/
    ros::Subscriber velocity_sub = nh.subscribe("cmd_vel_mux/input/teleop", 1000, &Callback);
    /**订阅编码器函数**/
    ros::Subscriber encoder_sub = nh.subscribe("encoder_cnts", 100, &encoderCallback);
    /**订阅speedT_wheel话题**/
    ros::Subscriber speed_sub = nh.subscribe("speedT_wheel", 1000, &speedCallback);

    ros::Subscriber imu_sub = nh.subscribe("imu_data", 1000, &imuCallback);
    std_msgs::Int16MultiArray msg_array;

    geometry_msgs::Quaternion qua;
    float32 oldx;
    float32 oldy;
    while (ros::ok())
    {
        ros::spinOnce();
        /**发布速度命令**/
        if (receive_cmd < 10)
        {
            msg_array.data.clear();
            msg_array.data.push_back(controller.mot.motor_left);
            msg_array.data.push_back(controller.mot.motor_right);
            velocity_pub.publish(msg_array);
            receive_cmd++;
        }
        else
        {
            msg_array.data.clear();
            msg_array.data.push_back(0);
            msg_array.data.push_back(0);
            velocity_pub.publish(msg_array);
            receive_cmd++;
        }
        if (receive_cmd > 1000)
        {
            receive_cmd = 100;
        }
        //        ROS_INFO("receive_cmd is %i",receive_cmd);

        /**发布里程计数据**/
        odom.header.stamp = ros::Time::now();
        odom.header.frame_id = "odom";
        odom.child_frame_id = "base_footprint";

        oldx = odom.pose.pose.position.x;
        oldy = odom.pose.pose.position.y;

        odom.pose.pose.position.x = controller.pose_.x;
        odom.pose.pose.position.y = controller.pose_.y;
        odom.pose.pose.position.z = 0;
        if (ODOM_USE_IMU > 0)
        {
            qua.x = x;
            qua.y = y;
            qua.z = z;
            qua.w = w;
        }
        else
        {
            qua.x = 0;
            qua.y = 0;
            qua.z = controller.pose_.qua_z;
            qua.w = controller.pose_.qua_w;
        }
        odom.pose.pose.orientation = qua;

        if (odom.twist.twist.linear.x != 0 && odom.twist.twist.angular.z != 0)
        {
            odom.pose.covariance = {1e-3, 0, 0, 0, 0, 0,
                                    0, 1e-3, 0, 0, 0, 0,
                                    0, 0, 1e6, 0, 0, 0,
                                    0, 0, 0, 1e6, 0, 0,
                                    0, 0, 0, 0, 1e6, 0,
                                    0, 0, 0, 0, 0, 1e3};
        }
        else
        {
            odom.pose.covariance = {1e-9, 0, 0, 0, 0, 0,
                                    0, 1e-3, 1e-9, 0, 0, 0,
                                    0, 0, 1e6, 0, 0, 0,
                                    0, 0, 0, 1e6, 0, 0,
                                    0, 0, 0, 0, 1e6, 0,
                                    0, 0, 0, 0, 0, 1e-9};
        }

        if (odom.pose.pose.position.x - oldx >= 1 || odom.pose.pose.position.y - oldy >= 1)
        {
            ROS_INFO("odom_jump");
            ROS_INFO("odom_oldx:%f", oldx);
            ROS_INFO("odom_oldy:%f", oldy);
            ROS_INFO("odom_newx:%f", odom.pose.pose.position.x);
            ROS_INFO("odom_newy:%f", odom.pose.pose.position.y);
        }

        odom_pub.publish(odom);
        // 2018.9.17 把坐标变换注释由关闭变为打开
        tf::Transform transform;
        static tf::TransformBroadcaster br;
        transform.setOrigin(tf::Vector3(controller.pose_.x, controller.pose_.y, 0.0));
        tf::Quaternion q;

        if (ODOM_USE_IMU > 0)
        {
            q.setX(x);
            q.setY(y);
            q.setZ(z);
            q.setW(w);
        }
        else
        {
            q.setRPY(0, 0, controller.pose_.theta);
        }

        transform.setRotation(q);
        br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), "base_footprint", "odom"));
        loop_rate.sleep();
    }
    controller.close_thread();
    return 0;
}
