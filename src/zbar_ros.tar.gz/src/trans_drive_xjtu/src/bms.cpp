#include "bms.h"

BMS::BMS(string port_name)
{
    isOpenned = false;

    tx_buffer[0] = 0x0A; //电池地址
    tx_buffer[1] = 0xB0; //读命令
    tx_buffer[2] = 0x00; //数据偏移地址
    tx_buffer[3] = 0x43; //返回数据长度

    // bmsdata初始化
    bmsData.dumpEnergy = 0;
    bmsData.electricCurrent = 0;
    bmsData.energyPercentage = 0;
    bmsData.isCharging = 0;
    bmsData.isDischarging = 0;
    bmsData.totalVoltage = 0;
    bmsData.temperature0 = 0;
    bmsData.temperature1 = 0;
    bmsData.temperature2 = 0;
    bmsData.voltage_1 = 0;
    bmsData.voltage_2 = 0;
    bmsData.voltage_3 = 0;
    bmsData.voltage_4 = 0;
    bmsData.voltage_5 = 0;
    bmsData.voltage_6 = 0;
    bmsData.voltage_7 = 0;
    bmsData.voltage_8 = 0;
    bmsData.voltage_9 = 0;
    bmsData.voltage_10 = 0;
    bmsData.voltage_11 = 0;
    bmsData.voltage_12 = 0;
    bmsData.voltage_13 = 0;

    try
    {
        //初始化串口
        bms_serial.setPort(port_name);
        // 设置波特率
        bms_serial.setBaudrate(BMS_PORT);
        // 设置打开超时时间
        serial::Timeout to = serial::Timeout::simpleTimeout(3000);
        bms_serial.setTimeout(to);
        bms_serial.open();

        if (bms_serial.isOpen())
        {
            isOpenned = true;
            cout << "The bms serial has been opened!" << endl;

            // 开启线程
            int ret = start();
            if (ret == 0)
            {
                cout << "Create BMS pthread successfully!" << endl;
            }
        }
        else
        {
            bms_serial.open();
        }
    }
    catch (serial::IOException &e)
    {
        cout << "Can not open the bms serial!" << endl;
    }
}

BMS::~BMS()
{
    isOpenned = false;
}

void *BMS::start_thread(void *arg)
{
    BMS *ptr = (BMS *)arg;
    ptr->explain();
}

int BMS::start()
{
    if (pthread_create(&pid_, NULL, start_thread, (void *)this) != 0) //´创建一个线程(必须是全局函数)
    {
        return -1;
    }
    return 0;
}

void BMS::explain()
{
    while (isOpenned)
    {

        bms_serial.write(tx_buffer, 4);

        bms_serial.read(get_buffer, 67);

        //        printSerial(get_buffer,67);
        bmsData.voltage_1 = get_buffer[0] * 256 + get_buffer[1];
        bmsData.voltage_2 = get_buffer[2] * 256 + get_buffer[3];
        bmsData.voltage_3 = get_buffer[4] * 256 + get_buffer[5];
        bmsData.voltage_4 = get_buffer[6] * 256 + get_buffer[7];
        bmsData.voltage_5 = get_buffer[8] * 256 + get_buffer[9];
        bmsData.voltage_6 = get_buffer[10] * 256 + get_buffer[11];
        bmsData.voltage_7 = get_buffer[12] * 256 + get_buffer[13];
        bmsData.voltage_8 = get_buffer[14] * 256 + get_buffer[15];
        bmsData.voltage_9 = get_buffer[16] * 256 + get_buffer[17];
        bmsData.voltage_10 = get_buffer[18] * 256 + get_buffer[19];
        bmsData.voltage_11 = get_buffer[20] * 256 + get_buffer[21];
        bmsData.voltage_12 = get_buffer[22] * 256 + get_buffer[23];
        bmsData.voltage_13 = get_buffer[24] * 256 + get_buffer[25];
        // bmsData.voltage_14 = get_buffer[26] * 256 + get_buffer[27];
        // bmsData.voltage_15 = get_buffer[28] * 256 + get_buffer[29];

        bmsData.totalVoltage = get_buffer[32] * 256 * 256 * 256 + get_buffer[33] * 256 * 256 + get_buffer[34] * 256 + get_buffer[35];
        //        if((get_buffer[36] & 0x80) == 0x80)
        //        {
        //            // 最高位为1,电流为负值
        //            bmsData.electricCurrent = (get_buffer[36] & 0x7F) * 256 * 256 * 256 + get_buffer[37] * 256 * 256 + get_buffer[38] * 256 + get_buffer[39];
        //            bmsData.electricCurrent = - bmsData.electricCurrent;
        //        }else{
        //            // 最高位为0,电流为正值
        //            bmsData.electricCurrent = get_buffer[36] * 256 * 256 * 256 + get_buffer[37] * 256 * 256 + get_buffer[38] * 256 + get_buffer[39];
        //        }
        bmsData.electricCurrent = get_buffer[36] * 256 * 256 * 256 + get_buffer[37] * 256 * 256 + get_buffer[38] * 256 + get_buffer[39];

        if ((get_buffer[40] & 0x80) == 0x80)
        {
            // 最高位为1,温度为负值
            bmsData.temperature0 = (get_buffer[40] & 0x7F) * 256 + get_buffer[41];
            bmsData.temperature0 = -bmsData.temperature0;
        }
        else
        {
            // 最高位为0,温度为正值
            bmsData.temperature0 = get_buffer[40] * 256 + get_buffer[41];
        }
        if ((get_buffer[42] & 0x80) == 0x80)
        {
            bmsData.temperature1 = (get_buffer[42] & 0x7F) * 256 + get_buffer[43];
            bmsData.temperature1 = -bmsData.temperature1;
        }
        else
        {
            bmsData.temperature1 = get_buffer[42] * 256 + get_buffer[43];
        }
        if ((get_buffer[44] & 0x80) == 0x80)
        {
            bmsData.temperature2 = (get_buffer[44] & 0x7F) * 256 + get_buffer[45];
            bmsData.temperature2 = -bmsData.temperature2;
        }
        else
        {
            bmsData.temperature2 = get_buffer[44] * 256 + get_buffer[45];
        }
        // 电池充满容量
        bmsData.dumpEnergy = get_buffer[46] * 256 * 256 * 256 + get_buffer[47] * 256 * 256 + get_buffer[48] * 256 + get_buffer[49];
        bmsData.leftEnergy = get_buffer[50] * 256 * 256 * 256 + get_buffer[51] * 256 * 256 + get_buffer[52] * 256 + get_buffer[53];
        bmsData.energyPercentage = get_buffer[54] * 256 + get_buffer[55];

        if ((get_buffer[59] & 0x80) == 0x80)
        {
            bmsData.isCharging = 1;
        }
        else
        {
            bmsData.isCharging = 0;
        }
        if ((get_buffer[59] & 0x40) == 0x40)
        {
            bmsData.isDischarging = 1;
        }
        else
        {
            bmsData.isDischarging = 0;
        }

            //    cout<<bmsData.voltage_1<<" "<<bmsData.voltage_2<<" "<<bmsData.voltage_3<<" "<<bmsData.voltage_4<<" "<<bmsData.voltage_5<<
            //          " "<<bmsData.voltage_6<<" "<<bmsData.voltage_7<<" "<<bmsData.totalVoltage<<" "<<bmsData.electricCurrent<<" "<<
            //          bmsData.temperature0<<" "<<bmsData.temperature1<<" "<<bmsData.temperature2<<" "<<bmsData.dumpEnergy<<" "<<
            //          bmsData.leftEnergy<<" "<<bmsData.energyPercentage<<" "<<bmsData.isCharging<<" "<<bmsData.isDischarging<<endl;
    }
}

void BMS::printSerial(uint8_t *data, int8 len)
{
    for (int k = 0; k < len; k++)
    {
        //printf("%x ",data[k]);
    }
    //printf("\r\n");
}

void BMS::closeUart()
{
    if (isOpenned)
    {
        isOpenned = false;
        sleep(1);
        bms_serial.close();
        cout << "bms serial has been closed!" << endl;
    }
}
