#ifndef CONTROLLER_H
#define CONTROLLER_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <boost/lexical_cast.hpp>
#include <chrono>
#include <boost/bind.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <pthread.h>
#include "namesapce_v.h"
#include <ctime>
#include <math.h>

using namespace std;

class Controller
{
private:

    /**两轮差速底盘的两个主动轮之间的距离**/
    float32 base_width;
    /**行走一米编码器的数值**/
    float32 ticks_meter;
    /**50ms的控制周期**/
    int16 duration;


    pthread_t pid;

    static void * start_thread(void* arg);// //静态成员函数

public:

    youi_robot_namespace::RobotMotorCmd mot;
    youi_robot_namespace::RobotEncoderData encoder_;
    youi_robot_namespace::RobotPoseData pose_;

    bool publish_odom;

    int64 enc_left;
    int64 enc_right;

    time_t t_next;
    time_t now;
    /**下一个时刻时间戳**/
    time_t then;
    /**循环内时间间隔**/
    time_t elapsed;
    /** 陀螺仪测量的角度 **/
    float theta;

public:

    Controller();
    ~Controller();
    /**
     * @brief 启动线程
     *
     * @return 无返回
     */
    int start();
    /**
     * @brief 延时函数
     *
     * @param mseconds 毫秒
     * @return 无返回
     */
    void Delay(int mseconds);
    /**
     * @brief 讲twist类型的消息转化为左右电机的控制命令
     *
     * @return 无返回
     */
    void twist2motor(float32 linear_x ,float32 angular_z);
    /**根据编码器生成里程计数据**/
    void produce_odom();
    /**获取系统时间**/
    time_t getTime();
    /**释放资源**/
    void close_thread();
};

#endif

