#ifndef BMS_H
#define BMS_H

#include "namesapce_v.h"
#include "serial/serial.h"
#include "serial/v8stdint.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <string>

using namespace std;

class BMS
{
public:
    youi_robot_namespace::RobotBmsData bmsData;
    // 判断串口是否已经打开
    bool isOpenned;

    serial::Serial bms_serial;

    // 读取bms数据的buffer
    uint8_t tx_buffer[4];

    uint8_t get_buffer[67];

    // 串口名称
    string port_name;

public:
    BMS(string port_name);
    ~BMS();
    pthread_t pid_;
    static void * start_thread(void* arg);// //静态成员函数
    int start();

    /**
     * @brief 对串口数据进行解析
     * @return　无返回
     */
    void explain();

    /**
     * @brief 打印串口数据
     *
     * @param data     串口数据buffer
     * @param len      buffer的长度
     */
    void printSerial(uint8_t *data, int8 len);
    /**
     * @brief 关闭串口，恢复传感器数据
     *
     * @return 无返回
     */
    void closeUart();
};

#endif
