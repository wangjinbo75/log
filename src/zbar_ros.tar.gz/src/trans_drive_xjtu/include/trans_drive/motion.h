#ifndef MOTION_H
#define MOTION_H

#define STX 0x02
#define ID_HEX 0x00
#define ETX 0x03

#define USER_REC_LEN 255       //最大接收字节数 255
#define USER_SED_LEN 255       //最大发送字节数 255
#define UART_LINE_NUM_START 3  //链路层里接收数据个数的开始位置
#define UART_LINE_DEVICE_START 5
#define UART_LINE_CMD_START 7
#define CRC_INIT 0xFFFF

//设备列表
#define HEARTBEAT_MESSAGE 0x05  //
#define KINCO_DRIVER 0x11       // KINCO驱动器设备号
#define RELAY 0x13              //充电继电器通断

//继电器
#define RELAY_ENQ 0x00              //查询继电器状态
#define SET_RELAY 0x01              // 设置继电器通断
#define SET_RELAY_TIME 0x02         // 设置继电器通断时间

#define ACK 0x06
#define NACK 0x15

#define ID_SEND_LIN_START 1
#define HANDSHAKE_SEND_LIN_START 2
#define SEND_NUM_SEND_LIN_START 4
#define DEVICE_SEND_LIN_START 6
#define CMD_SEND_LINE_START 8
#define DATA_SEND_LIN_START 10
#define CRC_SEND_LIN_START 18
#define ETX_SEND_LIN_START 22

#define ID_RECE_LIN_START 1
#define HANDSHAKE_RECE_LIN_START 2
#define NUM_RECE_LIN_START 4
#define DEVICE_RECE_LIN_START 6
#define CMD_RECE_LINE_START 8
#define DATA_RECE_LIN_START 10
#define CRC_RECE_LIN_START 18
#define ETX_RECE_LIN_START 22

//步科驱动器
#define CHECK_ENQ 0x00              //查询驱动器状态
#define CHECK_ABS_POSA 0x01         // left编码器脉冲查询
#define CHECK_ABS_POSB 0x02         // right编码器脉冲查询
#define CHECK_CUR_SPEED 0x03        //查询电机速度
#define SET_TARG_SPEED 0x04         //设置电机速度
#define CANCLE_COLLISION_STOP 0x05  //取消碰撞急停

#define SEND_NUM 21  //除包头(0x02)包尾(0x03)外的数据个数
#define RECE_NUM 21  //除包头(0x02)包尾(0x03)外的数据个数

#include "namesapce_v.h"
#include <serial/serial.h>
#include <serial/v8stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define left_to_right true  //左右电机是否互换

using namespace std;

class InfraredSerial {

public:
    // 判断串口是否被打开的标志位
    bool isOpenned;
    // 实例化串口函数
    serial::Serial ros_serial;

    int num =0;
    int relay_flag = 1;        //继电器通断状态
    bool data_update = false;  //接受数据是否更新
    bool speed_tx = false;    //速度是否发送成功
    bool speed_rx = false;    //速度是否接收成功
    bool encode_rx_left = false;    //左编码器脉冲是否读取成功
    bool encode_rx_right = false;    //右编码器脉冲是否读取成功
    unsigned char gHandShake;  //接收数据链路层HandShake
    unsigned char gDevice;     //接收数据链路层设备名
    unsigned char gCMD;        //接收数据链路层命令（ACK/NACK）
    unsigned char gNum;        //接收数据链路层NUM
    unsigned char gID;         //接收数据链路层ID
    unsigned char gData[8];  //接收数据链路层D0-D7

    unsigned char USER_RX_BUF[USER_REC_LEN];     //接收缓冲，最大USART_REC_LEN个字节
    unsigned char USER_TX_BUF[USER_SED_LEN];     //发送缓冲，HEX格式
    unsigned char USER_ASCII_BUF[USER_SED_LEN];  //发送缓冲，ASCII格式
    unsigned char *USER_RX_ASCII_BUF;

public:
    // 记录串口数据的变量
    youi_robot_namespace::RobotDecInfo information;
    youi_robot_namespace::RobotVelocityData velocity;
    youi_robot_namespace::RobotMotorCmd send_velocity;
    youi_robot_namespace::HeartbeatMesssage heartbeat_message;

    // 新建一个线程
    pthread_t pid;

    static void *start_thread(void *arg);  //静态成员函数
    int start();

    // 构造函数
    InfraredSerial();

    // 析构函数
    ~InfraredSerial();

    /**
     * @brief 获得左编码器脉冲
     * @return　无返回
     */
    void uart_get_encode_left();

    /**
 * @brief 获得右编码器脉冲
 * @return　无返回
 */
    void uart_get_encode_right();

    /**
     * @brief 获得电机速度
     * @return　无返回
     */
    void uart_get_speed();

    /**
     * @brief 获得驱动器状态
     * @return　无返回
     */
    void uart_get_kinco_state();

    /**
     * @brief 获得驱动器状态
     * @return　无返回
     */
    void uart_get_heartbeat_message();

    /**
     * @brief 向串口写入左右轮的速度
     * @return　false,发送速度失败，true,发送速度成功
     */
    void uart_send_speed(short left, short right);

    /**
     * @brief 向串口写入左右轮的速度
     * @return　false,发送速度失败，true,发送速度成功
     */
    void uart_set_relay();

    /**
     * @brief 向串口写入左右轮的速度,使用原来的协议
     * @return　无返回
     */
    void uart_write_origin(int16 left, int16 right);

    /**
     * @brief 将r/min的反馈速度变为线速度和角速度
     *
     * @param left 左轮转速
     * @param right 右轮转速
     * @return　RobotVelocityData
     */
    youi_robot_namespace::RobotVelocityData motorTotwist(int16 left, int16 right);

    /**
     * @brief 对串口数据进行解析
     * @return　无返回
     */
    void uart_explain();

    /**
     * @brief 串口读写main函数,加入状态机
     * @return　无返回
     */
    void uart_main();

    /**
     * @brief 打印串口数据
     *
     * @param data     串口数据buffer
     * @param len      buffer的长度
     */
    void printSerialSend();

    /**
     * @brief 关闭串口，恢复传感器数据
     *
     * @return 无返回
     */
    void closeUart();

    void CRC_CHECK();

    void H2A();

    unsigned short CRC16_CHECK(unsigned char Data, unsigned short CRC_Init);

    unsigned char HEXtoASCII(unsigned char TxData);

    unsigned char ASCIItoHEX(unsigned char RxData);

protected:
};

#endif
