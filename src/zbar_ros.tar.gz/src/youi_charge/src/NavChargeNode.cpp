#include "autocharge/AutoCharge.h"
#include "ros/ros.h"

int main(int argc, char **argv)
{
    // Set up ROS.
    ros::init(argc, argv, "auto_charge");
    ros::NodeHandle nh("~");
    ros::Rate rate(20);

    // Create a new node_example::Talker object.
    AutoCharge node(nh, rate);

    // Let ROS handle all callbacks.
    // while(node._isRunning==true)
    // {
    //     ros::spinOnce();
    // }
    ros::spin();
    return 0;
}
