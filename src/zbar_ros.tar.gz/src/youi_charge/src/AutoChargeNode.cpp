#include "autocharge/AutoCharge.h"
#include "ros/ros.h"

int main(int argc, char **argv)
{
    // Set up ROS.
    ros::init(argc, argv, "auto_charge");
    ros::NodeHandle nh("~");
    ros::Rate rate(20);
    
    AutoCharge node(nh, rate);

    // Let ROS handle all callbacks.
    ros::spin();

    return 0;
}
