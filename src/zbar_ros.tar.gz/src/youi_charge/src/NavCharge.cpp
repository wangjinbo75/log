#include "autocharge/AutoCharge.h"
#include "boost/bind.hpp"
#include "geometry_msgs/Twist.h"
#include "trans_drive/msgs/Battery.h"
#include "std_msgs/Bool.h"
#include "ros/ros.h"
#include <chrono>
#include <cmath>

AutoCharge::AutoCharge(ros::NodeHandle nh, ros::Rate rate) : _nh(nh), _isGoCharge(false), _isRunning(false), _isOverTime(false), looprate(rate)
{
    StartThread();
    _isQRSub = _nh.subscribe("qrlocate_pose", 1, &AutoCharge::QRCallBack, this);
    _isChargeSub = _nh.subscribe("is_charge", 1, &AutoCharge::GoChargeCallBack, this);
    _gyroYawSub = _nh.subscribe("imu_data", 1, &AutoCharge::GyroCallBack, this);
    _odomSub = _nh.subscribe("odom", 1, &AutoCharge::OdomCallBack, this);
    _batterysub = _nh.subscribe("bms_data", 1, &AutoCharge::bmsCallback, this);
    _velPub = _nh.advertise<geometry_msgs::Twist>("cmd_vel_mux/input/teleop", 1);
    _relaypub = _nh.advertise<std_msgs::Bool>("relay_charge", 10);
    _ischarging = 0;
    //_isGoCharge = 1; //调试用
    _nh.getParam("kSleep", kSleep);
    _nh.getParam("kOverTime", kOverTime);
    _nh.getParam("D_camera_center", D_camera_center);
    _nh.getParam("max_bias", max_bias);
    _nh.getParam("left_y_fix", left_y_fix);
    _nh.getParam("right_y_fix", right_y_fix);
    _nh.getParam("D_stop", D_stop);
    _nh.getParam("angleVel", angleVel);
    _nh.getParam("lineVel", lineVel);
    _nh.getParam("angleBias", angleBias);
    _nh.getParam("lineBias", lineBias);
    _nh.getParam("goalpose_x", goalpose_x);
    _nh.getParam("goalpose_y", goalpose_y);
    _nh.getParam("b_min_bias", b_min_bias);
    _nh.getParam("b_max_bias", b_max_bias);
    _nh.getParam("b_angleVel_middle", b_angleVel_middle);
    _nh.getParam("b_angleVel_max", b_angleVel_max);
    _nh.getParam("a_min_bias", a_min_bias);
    _nh.getParam("a_max_bias", a_max_bias);
    _nh.getParam("a_angleVel_middle", a_angleVel_middle);
    _nh.getParam("a_angleVel_max", a_angleVel_max);
    _nh.getParam("b_tolerant", b_tolerant);
    _nh.getParam("lowpower", lowpower);
    // ROS_INFO("D_stop:%f\n", D_stop);
}

AutoCharge::~AutoCharge()
{
    StopThread();
}

void AutoCharge::bmsCallback(const trans_drive::BatteryConstPtr &msg)
{
    _batteryPercentage = msg->rsoc;      //电量百分比
    _voltage = msg->voltage / 1000.0;    //电池电压
    _ischarging = msg->ischarging;       //电池是否充电
    _isdischarging = msg->isdischarging; //电池是否放电
    if(_batteryPercentage <=lowpower )
    {
        ROS_ERROR("the battery percentage is %d, please charge",_batteryPercentage);
    }
    
}

void AutoCharge::QRCallBack(const std_msgs::Float32MultiArray &msg)
{
    _isQR = msg.data[0];
    _distance = msg.data[1];
    _angle_a = msg.data[2];
    _angle_b = msg.data[3];
    // ROS_INFO("_isQR = %d, _distance = %d, angel_a = %d, _angle = %d\n",
    // _isQR, _distance, angel_a, _angle);
}

void AutoCharge::GoChargeCallBack(const std_msgs::Int8 &msg)
{
    _isGoCharge = msg.data == 0 ? false : true;
    ROS_INFO("_isGoCharge = %d\n", _isGoCharge);
}

void AutoCharge::GyroCallBack(const sensor_msgs::Imu &msg)
{
    //    Eigen::Quaterniond q(msg.orientation.w,msg.orientation.x,msg.orientation.y,msg.orientation.z);
    //    Eigen::Vector3d euler_angles = q.toRotationMatrix().eulerAngles(2,1,0);
    //    ROS_INFO("  %f",euler_angles.transpose());
    _gyro = OrientationToYaw(msg.orientation.x, msg.orientation.y, msg.orientation.z, msg.orientation.w) * RADIAN_TO_DEGREE;
    // ROS_INFO("_gyro = %d\n", _gyro);
}

void AutoCharge::OdomCallBack(const nav_msgs::Odometry &msg)
{

    _pose.x = msg.pose.pose.position.x * 1000;
    _pose.y = msg.pose.pose.position.y * 1000;
    // ROS_INFO("pose.x = %d, pose.y = %d\n", _pose.x, _pose.y);
}

double AutoCharge::OrientationToYaw(double x, double y, double z, double w)
{
    return atan2(2 * (x * y + w * z), w * w + x * x - y * y - z * z);
}

int AutoCharge::FunctionThread()
{
    while (_isRunning && ros::ok())
    {
        if (_isGoCharge)
        {
            //运动到充电桩右前方
            actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> action("move_base", true);
            if (!action.waitForServer(ros::Duration(60)))
            {
                ROS_INFO("Can't connected to move base server");
            }
            action.cancelAllGoals();
            geometry_msgs::Pose goalpose;
            goalpose.position.x = goalpose_x;
            goalpose.position.y = goalpose_y;
            goalpose.position.z = 0;
            goalpose.orientation = tf::createQuaternionMsgFromRollPitchYaw(0, 0, 0);

            move_base_msgs::MoveBaseGoal goal;
            goal.target_pose.header.frame_id = "map";
            goal.target_pose.header.stamp = ros::Time::now();
            goal.target_pose.pose = goalpose;
            action.sendGoal(goal);

            bool finished_within_time = action.waitForResult(ros::Duration(180));
            if (!finished_within_time)
            {
                action.cancelGoal();
                _isGoCharge = false;
                break;
            }

            if (action.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
            {
                VelocityPublish(0, 0);
                sleep(1);
                Pose currPose;
                currPose.x = _pose.x;
                currPose.y = _pose.y;

                int dir1 = 0;
                int dir2 = 0;
                double angleVelocity = 0;

                // std_msgs::Bool relay_msg;
                // relay_msg.data = true;
                // _relaypub.publish(relay_msg);
                //倒退到充电桩，实时检测校正
                while (ros::ok() && DistanceToTwoPose(currPose, _pose) < D_stop) //&& _distance > 140)(_ischarging == 0)
                {
                    // ROS_INFO("distance:%f", _distance);
                    ROS_INFO("distance:%f", DistanceToTwoPose(currPose, _pose));
                    if (_isQR)
                    {
                        currPose.x = _pose.x;
                        currPose.y = _pose.y;
                    }
                    else
                    {
                        _angle_a = 0;
                        _angle_b = 0;
                    }

                    dir1 = _angle_b > 0 ? -1 : 1;
                    ROS_INFO("b:%f\n", _angle_b * RADIAN_TO_DEGREE);
                    if (fabs(_angle_b * RADIAN_TO_DEGREE) < b_min_bias)
                    {
                        angleVelocity = 0;
                    }
                    else if (fabs(_angle_b * RADIAN_TO_DEGREE) < b_max_bias)
                    {
                        angleVelocity = b_angleVel_middle;
                    }
                    else
                    {
                        angleVelocity = b_angleVel_max;
                    }
                    // angleVel = (fabs(_angle_b*RADIAN_TO_DEGREE) < 3) ? 0.0 : (fabs(_angle_b*RADIAN_TO_DEGREE) < 20) ? 0.05 : 0.1;
                    //ROS_INFO("anglevel:%f\n", angleVelocity * dir1);
                    VelocityPublish(-0.05, angleVelocity * dir1);

                    dir2 = _angle_a > 0 ? -1 : 1;
                    //ROS_INFO("a:%f\n", _angle_a * RADIAN_TO_DEGREE);
                    // angleVel = (fabs(_angle_a) < 0.5) ? 0.0 : (fabs(_angle_a*RADIAN_TO_DEGREE) < 1) ? 0.05 : 0.1;
                    if (fabs(_angle_a * RADIAN_TO_DEGREE) < a_min_bias)
                    {
                        angleVelocity = 0;
                    }
                    else if (fabs(_angle_a * RADIAN_TO_DEGREE) < a_max_bias)
                    {
                        angleVelocity = a_angleVel_middle;
                    }
                    else
                    {
                        angleVelocity = a_angleVel_max;
                    }
                    //ROS_INFO("anglevel:%f\n", angleVelocity * dir2);
                    VelocityPublish(-0.05, angleVelocity * dir2);
                    looprate.sleep();
                }
                VelocityPublish(0, 0);
                std_msgs::Bool relay_msg;
                relay_msg.data = true;
                _relaypub.publish(relay_msg);
                ROS_INFO("+++++++++++++++++++++ robot arrive the charging generator ++++++++++++++++++++++++++++++");
                sleep(30);
                _isGoCharge = false;                
            }
        }
        if (_ischarging == 1)
        {
            ROS_INFO("+++++++++++++++++++++ trans is charging:%d/100, ++++++++++++++++++++++++++++++",_batteryPercentage);
        }
        if(_ischarging == 0)
        {
            //sleep(20);
            std_msgs::Bool relay_msg;
            relay_msg.data = false;
            _relaypub.publish(relay_msg);
        }
        if (_batteryPercentage == 100)
        {
            std_msgs::Bool relay_msg;
            relay_msg.data = false;
            _relaypub.publish(relay_msg);
            ROS_INFO("+++++++++++++++++++++ auto charge finished ++++++++++++++++++++++++++++++");
            //_isRunning = false;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(kSleep));
    }

    return false;
}

void AutoCharge::StartThread()
{
    ROS_INFO("start thread");
    if (_thread.joinable())
    {
        _thread.join();
    }
    _isRunning = true;
    _thread = std::thread(std::bind(&AutoCharge::FunctionThread, this));
}

void AutoCharge::StopThread()
{
    _isRunning = false;
    if (_thread.joinable())
    {
        ROS_WARN("thread is shut down");
        _thread.join();
    }
}

void AutoCharge::VelocityPublish(double speed, double angle)
{
    geometry_msgs::Twist twist;
    twist.linear.x = speed;
    twist.linear.y = 0.0;
    twist.linear.z = 0.0;

    twist.angular.x = 0.0;
    twist.angular.y = 0.0;
    twist.angular.z = angle;

    _velPub.publish(twist);
}

double AutoCharge::DistanceToTwoPose(Pose &pose1, Pose &pose2)
{
    return sqrt(pow(pose1.y - pose2.y, 2) + pow(pose1.x - pose2.x, 2));
}

double AutoCharge::AngleSumAndTransf(double angle1, double angle2)
{
    double sum = angle1 + angle2;
    if (sum > 180 * 1000)
    {
        sum -= 360 * 1000;
    }
    else if (sum < -180 * 1000)
    {
        sum += 360 * 1000;
    }
    else
    {
        sum = sum;
    }
    return sum;
}
void AutoCharge::VelocityAngle(double increment_angle)
{
    ROS_INFO("increment_angle:%f\n", increment_angle);

    double goal_Angle = _gyro + increment_angle;

    while (abs(goal_Angle - _gyro) >= angleBias)
    {
        // ROS_INFO("_gyro:%d\n",_gyro);
        // ROS_INFO("angle:%d\n",(goal_Angle-_gyro));
        if (goal_Angle - _gyro > 0)
        {
            VelocityPublish(0.0, angleVel);
        }
        else
        {
            VelocityPublish(0.0, -1 * angleVel);
        }
        looprate.sleep();
    }
    VelocityPublish(0.0, 0.0);
}
void AutoCharge::VelocityDistance(double increment_Dis)
{
    ROS_INFO("increment_Dis:%f\n", increment_Dis);
    Pose currPose;
    currPose.x = _pose.x;
    currPose.y = _pose.y;

    while (abs(DistanceToTwoPose(currPose, _pose) - abs(increment_Dis)) >= lineBias)
    {
        // ROS_INFO("distance:%d\n",abs(DistanceToTwoPose(currPose, _pose) - abs(increment_Dis)));
        if (DistanceToTwoPose(currPose, _pose) - abs(increment_Dis) > 0)
        {
            VelocityPublish(lineVel, 0.0);
        }
        else
        {
            VelocityPublish(-1 * lineVel, 0.0);
        }
        looprate.sleep();
    }
    VelocityPublish(0.0, 0.0);
}
