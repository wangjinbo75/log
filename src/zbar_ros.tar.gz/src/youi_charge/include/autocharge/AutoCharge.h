#ifndef __AUTOCHARGE_H__
#define __AUTOCHARGE_H__
/**
 * 规定长度单位为mm,角度单位为度，
 *
 *
 **/
#include "boost/thread.hpp"
#include "nav_msgs/Odometry.h"
#include "ros/ros.h"
#include "sensor_msgs/Imu.h"
#include "std_msgs/Float32MultiArray.h"
#include "std_msgs/Int8.h"
#include "trans_drive/msgs/Battery.h"
#include <iostream>
#include <thread>

#include <actionlib/client/simple_action_client.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <tf/transform_listener.h>

#define RADIAN_TO_DEGREE 180 / 3.1415926
#define DEGREE_TO_RADIAN 3.1415926 / 180
#define CAMERA_CENTER_DEGREE 11.9 //摄像头、转动中心连线与x方西夹角(度数)

struct Pose
{
  double x;
  double y;

  Pose()
  {
    x = 0;
    y = 0;
  }
};

class AutoCharge
{
  using Time = std::chrono::steady_clock::time_point;

public:
  //AutoCharge(ros::NodeHandle nh,ros::Rate rate,actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction>* _action);
  AutoCharge(ros::NodeHandle nh, ros::Rate rate);

  ~AutoCharge();

private:
  void StartThread();

  void StopThread();

  int FunctionThread();

  void bmsCallback(const trans_drive::BatteryConstPtr &msg);

  void QRCallBack(const std_msgs::Float32MultiArray &msg);

  void GoChargeCallBack(const std_msgs::Int8 &msg);

  void GyroCallBack(const sensor_msgs::Imu &msg);

  void OdomCallBack(const nav_msgs::Odometry &msg);

  double OrientationToYaw(double x, double y, double z, double w);

  void VelocityPublish(double speed, double angle);

  double DistanceToTwoPose(Pose &pose1, Pose &pose2);

  double AngleSumAndTransf(double angle1, double angle2);

  void VelocityAngle(double increment_angle);

  void VelocityDistance(double increment_Dis);
public:
  bool _isRunning;
private:
  ros::NodeHandle _nh;
  ros::Rate looprate;
  ros::Subscriber _isQRSub;
  ros::Subscriber _isChargeSub;
  ros::Subscriber _gyroYawSub;
  ros::Subscriber _odomSub;
  ros::Subscriber _batterysub;
  ros::Publisher _velPub;
  ros::Publisher _relaypub;
  std::thread _thread;

  double _distance;
  double _angle_a;
  double _angle_b;
  int _isQR = 0;
  bool _isGoCharge;
  bool _isOverTime;
  double _gyro;
  Pose _pose;

  //电池信息
  int _batteryPercentage; //电量百分比
  float _voltage;         //电池电压
  int _ischarging;        //电池是否充电
  int _isdischarging;     // 电池是否放电
  int lowpower;
  //运行参数
  int kSleep = 20;
  int kOverTime = 60 * 1000;
  double D_camera_center = 394;
  double max_bias = 60;
  double left_y_fix = 8.0;
  double right_y_fix = 40;
  double D_stop = 110;
  double angleVel = 0.2;
  double lineVel = 0.05;
  double angleBias = 3.5;
  double lineBias = 5;
  double goalpose_x = 0.2;
  double goalpose_y = -0.8;
  double b_tolerant = 0.2;
  double b_min_bias = 2;
  double b_max_bias = 10;
  double b_angleVel_middle = 0.02;
  double b_angleVel_max = 0.2;
  double a_min_bias = 0.2;
  double a_max_bias = 1;
  double a_angleVel_middle = 0.02;
  double a_angleVel_max = 0.1;
  //actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction>* action;
};

#endif // __AUTOCHARGE_H__
